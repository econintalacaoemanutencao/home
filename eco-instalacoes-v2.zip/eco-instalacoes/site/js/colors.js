// ============================================================
// colors.js — Identidade Visual da Eco Instalações Industriais
// ============================================================

const systemColors = {
  primary: '#F97316',       // Laranja — ação, botões, destaques
  secondary: '#475569',     // Slate médio — texto secundário, bordas
  dark: '#0F172A',          // Slate escuro — header, footer, fundos
  darkMid: '#1E293B',       // Slate intermediário — cards escuros
  light: '#F8FAFC',         // Off-white — fundos claros
  textMain: '#1E293B',      // Texto principal
  textMuted: '#64748B',     // Texto suave
  whatsappStart: '#25D366', // Verde WhatsApp início do gradiente
  whatsappEnd: '#128C7E',   // Verde WhatsApp fim do gradiente
};

// Injetar variáveis CSS no :root
(function applyColors() {
  const root = document.documentElement;
  root.style.setProperty('--primary-color', systemColors.primary);
  root.style.setProperty('--secondary-color', systemColors.secondary);
  root.style.setProperty('--dark-color', systemColors.dark);
  root.style.setProperty('--dark-mid-color', systemColors.darkMid);
  root.style.setProperty('--light-color', systemColors.light);
  root.style.setProperty('--text-main', systemColors.textMain);
  root.style.setProperty('--text-muted', systemColors.textMuted);
  root.style.setProperty('--whatsapp-start', systemColors.whatsappStart);
  root.style.setProperty('--whatsapp-end', systemColors.whatsappEnd);
})();
