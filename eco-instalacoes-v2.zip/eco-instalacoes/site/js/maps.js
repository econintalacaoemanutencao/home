// ============================================================
// maps.js — Mapa Google da Eco Instalações Industriais
// ============================================================

const embedCode = `<iframe src="https://www.google.com/maps/embed?pb=!3m2!1spt-BR!2sbr!4v1778269656383!5m2!1spt-BR!2sbr!6m8!1m7!1sFvbC58lHTbOpsAJfO41_3g!2m2!1d-25.2906983843043!2d-54.08453900356304!3f268.6716820285494!4f-15.808529890564671!5f0.7820865974627469" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>`;

(function injectMap() {
  const mapContainer = document.getElementById('map-container');
  if (mapContainer) {
    mapContainer.innerHTML = embedCode;
  }
})();
