// ============================================================
// content.js — Conteúdo Dinâmico da Eco Instalações Industriais
// ============================================================

const pageContent = {

  general: {
    pageTitle: 'Eco Instalações Industriais',
    favicon: 'favicon.ico',
    whatsappNumber: '5545988320733',
    whatsappMessage: 'Olá! Vim pelo site e gostaria de um orçamento.',
  },

  schema: {
    name: 'Eco Instalações Industriais',
    description: 'Empresa especialista em Montagem e Manutenção Industrial atendendo Foz do Iguaçu e região oeste do Paraná.',
    phone: '(45) 98832-0733',
    email: 'contato@ecoinstalacoesindustriais.com.br',
    address: {
      street: '',
      city: 'Foz do Iguaçu',
      state: 'PR',
      postalCode: '85851-000',
      country: 'BR',
    },
    geo: {
      latitude: -25.2906983843043,
      longitude: -54.08453900356304,
    },
  },

  aboutUs: {
    title: 'Quem Somos',
    description: `
      <p>A <strong>Eco Instalações Industriais</strong> é uma empresa paranaense com sólida trajetória em montagem e manutenção industrial. Atuamos no oeste do Paraná oferecendo soluções completas para indústrias de todos os portes.</p>
      <p>Nossa equipe é formada por profissionais qualificados em metalurgia, caldeiraria, soldagem, instalações elétricas, hidráulica industrial e pintura — garantindo um serviço integrado e de alta qualidade.</p>
      <p>Trabalhamos com rigorosos padrões de segurança e eficiência, para que sua produção não pare.</p>
    `,
  },

  features: {
    title: 'Nossas Especialidades',
    items: [
      {
        title: 'Montagem Industrial',
        description: 'Montagem eletromecânica, instalação de máquinas e equipamentos industriais com precisão e segurança.',
      },
      {
        title: 'Manutenção Preventiva e Corretiva',
        description: 'Programas de manutenção para evitar paradas inesperadas e maximizar a vida útil dos equipamentos.',
      },
      {
        title: 'Estruturas Metálicas',
        description: 'Fabricação e montagem de estruturas metálicas, galpões, mezaninos, cobertas e plataformas industriais.',
      },
      {
        title: 'Caldeiraria e Soldagem',
        description: 'Serviços especializados de caldeiraria, soldagem industrial e montagem de tubulações.',
      },
      {
        title: 'Pintura Industrial',
        description: 'Pintura epóxi, anticorrosiva, de piso industrial e estrutural, com tratamento de superfície adequado.',
      },
      {
        title: 'Hidráulica e Elétrica Industrial',
        description: 'Instalação e manutenção de sistemas hidráulicos e elétricos industriais com equipe certificada.',
      },
    ],
  },

  testimonials: {
    title: 'O Que Nossos Clientes Dizem',
    reviews: [
      {
        name: 'Carlos Eduardo',
        profession: 'Gerente de Produção',
        comment: 'A Eco instalou nossas máquinas com total profissionalismo. O prazo foi cumprido e a qualidade surpreendeu. Recomendo!',
      },
      {
        name: 'Márcia Souza',
        profession: 'Diretora Industrial',
        comment: 'Excelente empresa para manutenção preventiva. Reduziram nossas paradas em mais de 40%. Parceiros de longo prazo.',
      },
      {
        name: 'Roberto Fernandes',
        profession: 'Engenheiro de Manutenção',
        comment: 'Trabalho impecável nas estruturas metálicas do nosso galpão. Equipe técnica de primeiro nível.',
      },
    ],
  },

  footer: {
    description: 'Eco Instalações Industriais — soluções completas em montagem, manutenção e estruturas metálicas para a indústria do oeste paranaense.',
    servicesLinks: [
      { text: 'Montagem Industrial', href: '#servicos' },
      { text: 'Manutenção Industrial', href: '#servicos' },
      { text: 'Estruturas Metálicas', href: '#servicos' },
      { text: 'Caldeiraria e Soldagem', href: '#servicos' },
      { text: 'Pintura Industrial', href: '#servicos' },
      { text: 'Hidráulica Industrial', href: '#servicos' },
    ],
    schedule: [
      'Segunda a Sábado',
      '07:00 às 12:00',
      '14:00 às 20:00',
    ],
    phone: '(45) 98832-0733',
    address: 'Foz do Iguaçu — PR',
    copyright: '© 2025 Eco Instalações Industriais. Todos os direitos reservados.',
  },

};

// ============================================================
// Injeção de conteúdo no DOM
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
  const skip = window.skipInjection || [];

  // Schema JSON-LD
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    name: pageContent.schema.name,
    description: pageContent.schema.description,
    telephone: pageContent.schema.phone,
    email: pageContent.schema.email,
    address: {
      '@type': 'PostalAddress',
      addressLocality: pageContent.schema.address.city,
      addressRegion: pageContent.schema.address.state,
      postalCode: pageContent.schema.address.postalCode,
      addressCountry: pageContent.schema.address.country,
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: pageContent.schema.geo.latitude,
      longitude: pageContent.schema.geo.longitude,
    },
    openingHours: 'Mo-Sa 07:00-12:00,14:00-20:00',
  };
  const schemaScript = document.createElement('script');
  schemaScript.type = 'application/ld+json';
  schemaScript.textContent = JSON.stringify(schema);
  document.head.appendChild(schemaScript);

  // WhatsApp button
  const waBtn = document.getElementById('whatsapp-float');
  if (waBtn) {
    const msg = encodeURIComponent(pageContent.general.whatsappMessage);
    waBtn.href = `https://wa.me/${pageContent.general.whatsappNumber}?text=${msg}`;
    waBtn.innerHTML = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>`;
    waBtn.setAttribute('aria-label', 'Falar pelo WhatsApp');
    waBtn.setAttribute('target', '_blank');
    waBtn.setAttribute('rel', 'noopener noreferrer');
  }

  // About section
  if (!skip.includes('about')) {
    const aboutDesc = document.getElementById('about-desc');
    if (aboutDesc) aboutDesc.innerHTML = pageContent.aboutUs.description;
    const aboutTitle = document.getElementById('about-title');
    if (aboutTitle) aboutTitle.textContent = pageContent.aboutUs.title;
  }

  // Features section
  if (!skip.includes('features')) {
    const featuresList = document.getElementById('features-list');
    if (featuresList) {
      featuresList.innerHTML = pageContent.features.items.map(item => `
        <div class="feature-card">
          <h3>${item.title}</h3>
          <p>${item.description}</p>
        </div>
      `).join('');
    }
    const featuresTitle = document.getElementById('features-title');
    if (featuresTitle) featuresTitle.textContent = pageContent.features.title;
  }

  // Testimonials
  const reviewsList = document.getElementById('reviews-list');
  if (reviewsList) {
    reviewsList.innerHTML = pageContent.testimonials.reviews.map(r => `
      <div class="review-card">
        <p class="review-comment">"${r.comment}"</p>
        <strong class="review-name">${r.name}</strong>
        <span class="review-profession">${r.profession}</span>
      </div>
    `).join('');
  }
  const testimonialsTitle = document.getElementById('testimonials-title');
  if (testimonialsTitle) testimonialsTitle.textContent = pageContent.testimonials.title;

  // Footer
  const footerDesc = document.getElementById('footer-desc');
  if (footerDesc) footerDesc.textContent = pageContent.footer.description;

  const footerPhone = document.getElementById('footer-phone');
  if (footerPhone) footerPhone.textContent = pageContent.footer.phone;

  const footerAddress = document.getElementById('footer-address');
  if (footerAddress) footerAddress.textContent = pageContent.footer.address;

  const footerSchedule = document.getElementById('footer-schedule');
  if (footerSchedule) {
    footerSchedule.innerHTML = pageContent.footer.schedule.map(s => `<li>${s}</li>`).join('');
  }

  const footerLinks = document.getElementById('footer-services-links');
  if (footerLinks) {
    footerLinks.innerHTML = pageContent.footer.servicesLinks.map(l => `<li><a href="${l.href}">${l.text}</a></li>`).join('');
  }

  const footerCopy = document.getElementById('footer-copyright');
  if (footerCopy) footerCopy.textContent = pageContent.footer.copyright;
});
