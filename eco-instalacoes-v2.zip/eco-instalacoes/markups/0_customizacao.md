# Customização do Site

- `EMPRESA_NOME`: Eco Instalações Industriais
- `DOMINIO_DO_SITE`: ecoinstalacoesindustriais.com.br
- `CATEGORIA_PRINCIPAL`: Montagem e Manutenção Industrial
- `TELEFONE_WHATSAPP`: +5545988320733
- `TELEFONE_LIGAR`: (45) 98832-0733
- `HORARIO_FUNCIONAMENTO`: Das 07:00 às 12:00 e das 14:00 às 20:00, 6 Dias por Semana
- `COR_MARCA`: #0F172A, #475569, #F8FAFC, #F97316, #1E293B
- `CIDADE_1`: Foz do Iguaçu
- `GBP_BUSINESS_EMBED_CODE`: <iframe src="https://www.google.com/maps/embed?pb=!3m2!1spt-BR!2sbr!4v1778269656383!5m2!1spt-BR!2sbr!6m8!1m7!1sFvbC58lHTbOpsAJfO41_3g!2m2!1d-25.2906983843043!2d-54.08453900356304!3f268.6716820285494!4f-15.808529890564671!5f0.7820865974627469" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
