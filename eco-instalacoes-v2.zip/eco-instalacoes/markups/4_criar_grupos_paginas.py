"""
Script para agrupar páginas em blocos.
Lê '9_paginas.md' e cria 'grupos-de-paginas.md' com as páginas divididas em grupos de 6.
"""
import os

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    input_file = os.path.join(base_dir, '9_paginas.md')
    output_file = os.path.join(base_dir, 'grupos-de-paginas.md')
    lines_per_group = 6

    if not os.path.exists(input_file):
        print(f"Erro: Arquivo '{input_file}' não encontrado.")
        return

    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f if line.strip()]
    except IOError as e:
        print(f"Erro ao ler arquivo '{input_file}': {e}")
        return

    if not lines:
        print(f"Aviso: O arquivo '{input_file}' está vazio.")
        return

    try:
        with open(output_file, 'w', encoding='utf-8') as f_out:
            total_groups = 0
            for i in range(0, len(lines), lines_per_group):
                chunk = lines[i:i + lines_per_group]
                group_number = (i // lines_per_group) + 1
                f_out.write(f"### Grupo {group_number}\n\n")
                f_out.write('\n'.join(chunk))
                f_out.write('\n\n')
                total_groups += 1
        print(f"Concluído! '{output_file}' criado com {total_groups} grupos de {lines_per_group} páginas.")
    except IOError as e:
        print(f"Erro ao escrever arquivo '{output_file}': {e}")

if __name__ == "__main__":
    main()
