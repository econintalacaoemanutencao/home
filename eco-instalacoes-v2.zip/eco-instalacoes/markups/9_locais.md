Ampére
Assis Chateaubriand
Cafelândia
Capanema
Cascavel
Céu Azul
Chopinzinho
Corbélia
Coronel Vivida
Dionísio Cerqueira
Dois Vizinhos
Foz Do Iguaçu
Francisco Beltrão
Guaíra
Itaipulândia
Laranjeiras Do Sul
Mamborê
Marechal Cândido Rondon
Marmeleiro
Matelândia
Medianeira
Missal
Nova Laranjeiras
Palotina
Pato Branco
Quedas Do Iguaçu
Ramilândia
Realeza
Salto Do Lontra
Santa Helena
Santa Tereza Do Oeste
Santa Terezinha De Itaipu
Santo Antônio Do Sudoeste
São Miguel Do Iguaçu
Serranópolis Do Iguaçu
Toledo
Ubiratã
Umuarama
Vera Cruz Do Oeste
