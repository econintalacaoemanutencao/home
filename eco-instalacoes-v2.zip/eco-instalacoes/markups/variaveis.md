# Guia de Variáveis Editáveis

Este documento lista todas as variáveis e objetos JavaScript que controlam o conteúdo e a aparência do site.

---

## 1. Conteúdo Principal (`js/content.js`)

### **Geral (SEO e WhatsApp)**
- `general.pageTitle`: Título da aba do navegador e nome principal.
- `general.favicon`: Caminho do ícone do site.
- `general.whatsappNumber`: Número do WhatsApp (apenas números, com DDD).
- `general.whatsappMessage`: Mensagem automática que o cliente envia ao clicar no botão.

### **Schema (SEO Técnico)**
- `schema.name`: Nome da empresa para o Google.
- `schema.description`: Descrição da empresa para o Google.
- `schema.phone` / `email`: Dados de contato técnico.
- `schema.address`: Objeto com rua, cidade, estado, CEP e país.
- `schema.geo`: Latitude e Longitude para localização precisa.

### **Sobre Nós**
- `aboutUs.title`: Título da seção.
- `aboutUs.description`: Texto descritivo (aceita HTML).

### **Especialidades (Soluções)**
- `features.title`: Título da seção.
- `features.items`: Lista de cards com `title` e `description`.

### **Depoimentos**
- `testimonials.title`: Título da seção de avaliações.
- `testimonials.reviews`: Lista com `name`, `profession` e `comment`.

### **Rodapé (Footer)**
- `footer.description`: Texto sobre a empresa no rodapé.
- `footer.schedule`: Horários de funcionamento.
- `footer.phone`: Telefone exibido no rodapé.
- `footer.copyright`: Texto de direitos autorais.

---

## 2. Cores do Sistema (`js/colors.js`)

- `primary`: Cor principal de destaque (botões, ícones ativos).
- `secondary`: Cor secundária para contrastes.
- `dark`: Cor de fundos escuros.
- `textMain`: Cor principal dos parágrafos.
- `whatsappStart` / `whatsappEnd`: Cores do gradiente do botão flutuante do WhatsApp.

---

## 3. Mapa do Google (`js/maps.js`)

- `embedCode`: Contém a tag `<iframe>` gerada pelo Google Maps.

---

## 4. Estrutura de Cabeçalho e Rodapé (`js/header.js` e `js/footer.js`)

Contêm a estrutura HTML injetada dinamicamente no site.
