"""
8_gerar_projeto_completo.py
===========================
Gerador master do projeto Eco Instalações Industriais.

Gera:
  - 1.404 páginas kw+cidade (regeneradas com 1.200+ palavras, footer novo)
  - 195 páginas kw+avenida+cidade (5 avenidas × 39 cidades, palavra-chave principal)
  - mapa-do-site.html atualizado
  - sitemap.xml atualizado
  - index.html atualizado com novo rodapé

Novidades:
  - Footer com "Links Úteis" (nofollow) + link Mapa do Site em todas as páginas
  - Links específicos de Medianeira apenas nas páginas dessa cidade
  - Mínimo 1.200 palavras por página
  - Pools maiores para 100% originalidade
"""

import os, re, unicodedata, random

# ── Helpers ────────────────────────────────────────────────────────────────────

def slugify(v):
    v = unicodedata.normalize('NFKD', v).encode('ascii', 'ignore').decode('ascii')
    v = re.sub(r'[^\w\s-]', '', v).strip().lower()
    return re.sub(r'[-\s]+', '-', v)

def fmt(t, **kw):
    try:
        return t.format(**kw)
    except KeyError:
        return t

# ── Configuração da empresa ────────────────────────────────────────────────────

EMPRESA   = "Eco Instalações Industriais"
TELEFONE  = "(45) 98832-0733"
WHATSAPP  = "5545988320733"
DOMINIO   = "https://ecoinstalacoesindustriais.com.br"
HORARIO   = "Segunda a Sábado, das 07h às 12h e das 14h às 20h"
ESTADO    = "Paraná"

# ── Avenidas por cidade ────────────────────────────────────────────────────────

AVENIDAS = {
    "Ampére":                    ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Assis Chateaubriand":       ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Cafelândia":                ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Capanema":                  ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Cascavel":                  ["Brasil","Tancredo Neves","Tito Muffato","Curitiba","Paraná"],
    "Céu Azul":                  ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Chopinzinho":               ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Corbélia":                  ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Coronel Vivida":            ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Dionísio Cerqueira":        ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Dois Vizinhos":             ["Brasil","Paraná","João Paulo II","Industrial","Getúlio Vargas"],
    "Foz do Iguaçu":             ["Brasil","JK","República Argentina","Paraná","Jorge Schimmelpfeng"],
    "Francisco Beltrão":         ["Júlio Assis Cavalheiro","General Osório","Cristo Rei","Paraná","Progresso"],
    "Guaíra":                    ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Itaipulândia":              ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Laranjeiras do Sul":        ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Mamborê":                   ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Marechal Cândido Rondon":   ["Maripa","Independência","Brasil","Rio Grande do Sul","Paraná"],
    "Marmeleiro":                ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Matelândia":                ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Medianeira":                ["Brasil","Mauá","Paraná","Independência","Sete de Setembro"],
    "Missal":                    ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Nova Laranjeiras":          ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Palotina":                  ["Brasil","Paraná","Rio Grande do Sul","Industrial","Independência"],
    "Pato Branco":               ["Brasil","Tupi","Araricá","Presidente Kennedy","Tuiuti"],
    "Quedas do Iguaçu":          ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Ramilândia":                ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Realeza":                   ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Salto do Lontra":           ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Santa Helena":              ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Santa Tereza do Oeste":     ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Santa Terezinha de Itaipu": ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Santo Antônio do Sudoeste": ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "São Miguel do Iguaçu":      ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Serranópolis do Iguaçu":    ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Toledo":                    ["Maripá","Araucária","Brasil","Industrial","Quatro Ilhas"],
    "Ubiratã":                   ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Umuarama":                  ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
    "Vera Cruz do Oeste":        ["Brasil","Paraná","Industrial","Independência","Sete de Setembro"],
}

# ── Links úteis por cidade ─────────────────────────────────────────────────────

LINKS_UTEIS_MEDIANEIRA = [
    ("Prefeitura de Medianeira", "https://www.medianeira.pr.gov.br/"),
    ("IBGE — Medianeira", "https://cidades.ibge.gov.br/brasil/pr/medianeira/panorama"),
    ("NR-12 — Norma Regulamentadora", "https://www.gov.br/trabalho-e-emprego/pt-br/acesso-a-informacao/participacao-social/conselhos-e-orgaos-colegiados/comissao-tripartite-partitaria-permanente/normas-regulamentadora/normas-regulamentadoras-vigentes/norma-regulamentadora-no-12-nr-12"),
]

LINKS_UTEIS_GENERICOS = [
    ("NR-12 — Norma Regulamentadora", "https://www.gov.br/trabalho-e-emprego/pt-br/acesso-a-informacao/participacao-social/conselhos-e-orgaos-colegiados/comissao-tripartite-partitaria-permanente/normas-regulamentadora/normas-regulamentadoras-vigentes/norma-regulamentadora-no-12-nr-12"),
    ("IBGE — Cidades do Brasil", "https://cidades.ibge.gov.br/"),
]

# ── Pools de conteúdo — HERO ───────────────────────────────────────────────────

HERO_DESCS = [
    "A {empresa} atua em {loc} com soluções completas em {kw_lower}, unindo equipe técnica certificada, equipamentos modernos e total compromisso com a segurança e os prazos de entrega.",
    "Precisa de {kw_lower} em {loc}? A {empresa} tem a estrutura, a experiência e os profissionais certos para atender sua demanda industrial com agilidade, qualidade e custo competitivo.",
    "Com mais de uma década de atuação no oeste paranaense, a {empresa} é referência em {kw_lower} em {loc}. Diagnóstico gratuito, orçamento transparente e garantia formal em todos os serviços.",
    "A {empresa} combina tecnologia e expertise para oferecer {kw_lower} de alto nível em {loc}. Nossa equipe certificada garante cada etapa da execução com segurança e eficiência.",
    "Em {loc}, a {empresa} é o parceiro industrial de confiança para {kw_lower}. Profissionais próprios, equipamentos calibrados e um histórico comprovado de projetos entregues no prazo.",
    "Sua indústria em {loc} merece o melhor em {kw_lower}. A {empresa} entrega execução técnica impecável, suporte completo e garantia nos serviços — do diagnóstico à entrega final.",
    "Somos especialistas em {kw_lower} e atendemos {loc} com equipe própria certificada, métodos modernos e foco na satisfação do cliente. Solicite agora seu orçamento gratuito.",
    "A {empresa} chegou a {loc} para transformar a forma como as indústrias locais lidam com {kw_lower}. Eficiência, segurança e qualidade em cada projeto executado.",
    "Quando o assunto é {kw_lower} em {loc}, a {empresa} se destaca pela qualidade técnica, pela agilidade no atendimento e pela transparência em todas as etapas do projeto.",
    "Escolher o fornecedor certo de {kw_lower} em {loc} pode ser a diferença entre uma operação eficiente e prejuízos evitáveis. A {empresa} reúne experiência e profissionalismo para ser esse parceiro.",
    "Em {loc}, a {empresa} realiza {kw_lower} com equipe própria, sem terceirização das etapas críticas. Controle de qualidade total, do levantamento técnico à entrega final documentada.",
    "A indústria de {loc} conta com a {empresa} para soluções completas em {kw_lower}. Anos de experiência no oeste do Paraná garantem execução técnica rigorosa e resultados reais.",
]

# ── Pools — ABOUT ──────────────────────────────────────────────────────────────

ABOUT_PARAS = [
    [
        "A <strong>{empresa}</strong> é uma empresa paranaense consolidada no segmento de montagem e manutenção industrial. Presente em {loc} e em toda a região oeste do {estado}, oferecemos soluções técnicas completas para indústrias de diferentes portes e segmentos produtivos.",
        "Nossa equipe é composta por profissionais altamente qualificados em {kw_lower}, metalurgia, soldagem, instalações elétricas e hidráulica industrial. Cada projeto recebe atenção máxima aos detalhes, seguindo rigorosos padrões de segurança e qualidade que superam as expectativas dos clientes.",
        "Em {loc}, somos reconhecidos pela seriedade, pontualidade e excelência técnica. Nossa missão é contribuir diretamente para a eficiência e a competitividade da sua operação industrial, reduzindo custos de parada e aumentando a vida útil dos seus ativos.",
    ],
    [
        "Fundada com o propósito de elevar o padrão dos serviços industriais no oeste paranaense, a <strong>{empresa}</strong> chegou a {loc} para ser o parceiro técnico que as indústrias locais precisavam. Nossa abordagem combina rigor técnico, transparência e foco total no cliente.",
        "Trabalhamos com normas regulamentadoras NR-10, NR-12 e NR-33, garantindo a segurança de colaboradores, patrimônio e instalações em todos os projetos de {kw_lower} realizados em {loc}. Cada etapa é planejada, documentada e executada com profissionalismo.",
        "Com equipamentos modernos, veículos próprios e equipe capacitada, a {empresa} oferece mobilização rápida para {loc} e região, minimizando o tempo de espera e o impacto nas operações industriais do cliente.",
    ],
    [
        "A <strong>{empresa}</strong> acumula mais de uma década de experiência em projetos industriais no Paraná. Em {loc}, já realizamos dezenas de serviços de {kw_lower} para clientes dos setores alimentício, madeireiro, metalúrgico, plástico e de construção civil industrial.",
        "Nossa metodologia é simples e eficaz: ouvimos o cliente, realizamos levantamento técnico detalhado, apresentamos proposta clara e executamos com equipe própria e certificada. Não terceirizamos etapas críticas — isso garante controle de qualidade de ponta a ponta.",
        "O resultado é uma carteira de clientes fidelizados em {loc} e em toda a região, que reconhecem na {empresa} um parceiro confiável, pontual e comprometido com a excelência em {kw_lower}.",
    ],
    [
        "Com presença consolidada no oeste paranaense, a <strong>{empresa}</strong> leva até {loc} uma estrutura completa de {kw_lower}, com profissionais especializados e comprometidos com resultados reais e duradouros.",
        "Acreditamos que cada cliente é único. Por isso, desenvolvemos soluções personalizadas que atendem às especificidades de cada operação industrial em {loc}, sempre priorizando segurança, qualidade, eficiência e cumprimento de prazos.",
        "Nossa reputação foi construída projeto a projeto, cliente a cliente. Hoje somos referência em {kw_lower} no oeste do {estado} e orgulhamo-nos de um histórico comprovado de clientes satisfeitos em {loc} e nas cidades vizinhas.",
    ],
    [
        "A <strong>{empresa}</strong> nasceu da visão de que o mercado industrial do oeste paranaense merecia uma empresa que combinasse expertise técnica com atendimento humanizado. Em {loc}, essa filosofia se traduz em projetos de {kw_lower} executados com cuidado, precisão e responsabilidade.",
        "Nossa equipe técnica passa por atualização constante em normas de segurança, novas técnicas de {kw_lower} e uso de equipamentos modernos. Isso permite entregar soluções alinhadas com as melhores práticas do mercado nacional em {loc} e região.",
        "Seja um projeto de pequeno porte ou uma grande mobilização industrial, a {empresa} trata cada demanda com o mesmo nível de comprometimento. Em {loc}, isso significa respostas rápidas, execução impecável e suporte técnico mesmo após a entrega do serviço.",
    ],
    [
        "Quando uma indústria em {loc} precisa de {kw_lower}, a escolha do fornecedor faz toda a diferença. A <strong>{empresa}</strong> oferece muito mais do que mão de obra — oferece uma solução técnica completa, com diagnóstico, planejamento, execução e acompanhamento pós-serviço.",
        "Nosso diferencial está na integração das equipes: profissionais de elétrica, mecânica, caldeiraria, soldagem e pintura trabalham de forma coordenada, garantindo projetos de {kw_lower} entregues com qualidade e sem retrabalho em {loc}.",
        "A {empresa} investe continuamente em treinamentos, certificações e equipamentos para manter o padrão de excelência que nossos clientes em {loc} conhecem e confiam. Esse compromisso com a melhoria contínua é o que nos diferencia no mercado industrial paranaense.",
    ],
]

# ── Pools — FEATURES ──────────────────────────────────────────────────────────

FEATURES_POOL = [
    ("Diagnóstico Técnico Gratuito",      "Avaliamos sua necessidade em {loc} sem custos, identificando a melhor solução para {kw_lower} com precisão técnica e agilidade na resposta."),
    ("Equipe Própria e Certificada",      "Todos os nossos técnicos possuem certificações NR-10, NR-12 e NR-33, prontos para atuar com segurança em qualquer ambiente industrial em {loc}."),
    ("Cumprimento Rigoroso de Prazos",    "Planejamento detalhado e execução eficiente garantem que os serviços de {kw_lower} em {loc} sejam concluídos dentro do cronograma estabelecido."),
    ("Atendimento Regional Abrangente",   "Além de {loc}, a {empresa} atende mais de 39 municípios do oeste do {estado}, com mobilização rápida e suporte técnico local."),
    ("Garantia Formal nos Serviços",      "Todos os projetos de {kw_lower} realizados em {loc} pela {empresa} contam com garantia formal registrada, protegendo o seu investimento."),
    ("Orçamento 100% Transparente",       "Sem letras miúdas e sem surpresas: apresentamos orçamento detalhado e claro antes de iniciar qualquer trabalho de {kw_lower} em {loc}."),
    ("Equipamentos Modernos e Calibrados","Utilizamos ferramentas e equipamentos de última geração, calibrados e certificados, para garantir precisão e qualidade nos serviços em {loc}."),
    ("Suporte Pós-Serviço",               "Nosso relacionamento não termina na entrega. Oferecemos suporte técnico após a conclusão de cada projeto de {kw_lower} em {loc}."),
    ("Conformidade com Normas NR",        "Seguimos rigorosamente as normas regulamentadoras aplicáveis, protegendo colaboradores e patrimônio industrial em {loc}."),
    ("Soluções 360° Integradas",          "Da montagem à manutenção, passando por estruturas metálicas e pintura, oferecemos uma solução completa para sua indústria em {loc}."),
    ("Manutenção Preventiva Planejada",   "Desenvolvemos planos de manutenção preventiva em {loc} que reduzem paradas inesperadas e maximizam a produtividade da sua planta."),
    ("Mobilização Ágil",                  "Mobilizamos equipe e recursos com rapidez para minimizar o tempo de parada da sua operação industrial em {loc} e região."),
    ("Gestão Documental do Projeto",      "Entregamos relatórios técnicos detalhados de cada serviço realizado em {loc}, garantindo rastreabilidade e histórico completo para sua indústria."),
    ("Segurança do Trabalho em Campo",    "Nossa equipe aplica procedimentos rigorosos de segurança do trabalho em todos os projetos em {loc}, com supervisão constante e análise de risco prévia."),
    ("Soldagem com Múltiplos Processos",  "Realizamos soldagem por eletrodo revestido, MIG/MAG, TIG e outros processos homologados, atendendo diferentes especificações técnicas em {loc}."),
]

# ── Pools — SEO H2 ─────────────────────────────────────────────────────────────

SEO_H2 = [
    "{kw} em {loc}: Expertise que Faz a Diferença",
    "Por Que Contratar a {empresa} para {kw} em {loc}?",
    "{kw} em {loc} — Soluções Completas para sua Indústria",
    "Como Funciona o Serviço de {kw} em {loc}",
    "{kw} em {loc}: Qualidade Técnica e Total Confiabilidade",
    "O Guia Completo para Contratar {kw} em {loc}",
    "{kw} em {loc}: Tudo que sua Empresa Precisa Saber",
    "Referência em {kw} no Oeste do Paraná — Atendemos {loc}",
    "Indústrias de {loc} Confiam na {empresa} para {kw}",
    "Maximize a Eficiência da sua Planta com {kw} em {loc}",
    "A Importância do {kw} Profissional em {loc}",
    "{kw} em {loc}: Como a {empresa} Garante Resultados Superiores",
]

# ── Pools — SEO BODY ──────────────────────────────────────────────────────────

SEO_BODIES = [
"""<p>A contratação de uma empresa especializada em <strong>{kw_lower}</strong> em <strong>{loc}</strong> é um dos investimentos mais estratégicos que uma indústria pode fazer. Um serviço bem executado reduz custos operacionais, aumenta a vida útil dos equipamentos e garante a conformidade com as normas regulamentadoras vigentes. A <strong>{empresa}</strong> atua nesse segmento com metodologia rigorosa, equipe própria certificada e equipamentos de alta precisão.</p>

<h3>O que engloba o serviço de {kw} em {loc}?</h3>
<p>O escopo do serviço de {kw_lower} varia conforme a necessidade de cada cliente, mas em {loc} a {empresa} oferece uma cobertura completa: desde o diagnóstico inicial até a entrega documentada do projeto. Isso inclui levantamento técnico in loco, elaboração de proposta detalhada, mobilização da equipe, execução com controle de qualidade em cada etapa e relatório técnico final.</p>

<h3>Setores industriais atendidos em {loc}</h3>
<ul>
  <li><strong>Indústrias alimentícias e frigoríficos</strong> — com atenção especial às normas de higiene e segurança alimentar.</li>
  <li><strong>Metalúrgicas e empresas de estamparia</strong> — projetos de alta precisão para equipamentos de grande porte.</li>
  <li><strong>Madeireiras e serrarias</strong> — manutenção de linhas de produção com alta demanda operacional.</li>
  <li><strong>Agroindústrias e cooperativas</strong> — soluções integradas para plantas de processamento e beneficiamento.</li>
  <li><strong>Indústrias plásticas e de embalagem</strong> — instalação e manutenção de equipamentos de injeção e extrusão.</li>
  <li><strong>Construção civil industrial e infraestrutura</strong> — obras industriais com gestão técnica especializada.</li>
</ul>

<h3>Processo de execução em {loc}</h3>
<p>Nossa metodologia para {kw_lower} em {loc} segue um fluxo estruturado em seis etapas: <strong>(1)</strong> contato inicial e agendamento de visita técnica gratuita; <strong>(2)</strong> levantamento detalhado das necessidades; <strong>(3)</strong> elaboração de proposta técnica e orçamento transparente; <strong>(4)</strong> aprovação e assinatura de ordem de serviço; <strong>(5)</strong> execução com equipe certificada e supervisão contínua; <strong>(6)</strong> entrega formal com relatório técnico e garantia documentada.</p>

<h3>Por que a {empresa} se destaca em {loc}?</h3>
<p>Não terceirizamos etapas críticas dos projetos. Toda a execução de {kw_lower} em {loc} é realizada pela nossa equipe própria, o que garante controle de qualidade real, comunicação eficiente e responsabilidade total sobre o resultado. Além disso, nossa proximidade com {loc} permite mobilização rápida e suporte contínuo ao longo de todo o projeto.</p>

<h3>Segurança como prioridade absoluta</h3>
<p>Todos os projetos de {kw_lower} em {loc} seguem as normas regulamentadoras aplicáveis, incluindo NR-10 (segurança em instalações e serviços em eletricidade), NR-12 (segurança em máquinas e equipamentos) e NR-33 (segurança e saúde nos trabalhos em espaços confinados). Nossa equipe utiliza EPI completo, realiza análises de risco prévias e segue procedimentos operacionais padrão, garantindo a segurança de todos os envolvidos.</p>

<h3>Tecnologia e inovação aplicadas em {loc}</h3>
<p>A {empresa} investe constantemente em atualização técnica e em equipamentos modernos para oferecer o melhor serviço de {kw_lower} em {loc}. Utilizamos instrumentos de medição calibrados, softwares de planejamento de manutenção e técnicas de soldagem e montagem alinhadas com as melhores práticas do mercado industrial nacional.</p>

<p>Entre em contato agora pelo <strong>{telefone}</strong> ou envie uma mensagem pelo WhatsApp e receba um orçamento gratuito para {kw_lower} em {loc}. Atendemos <strong>{loc}</strong> e mais de 39 municípios do oeste paranaense de {horario}.</p>""",

"""<p>Quando uma empresa industrial em <strong>{loc}</strong> busca um fornecedor de <strong>{kw_lower}</strong>, a decisão vai muito além do preço. A qualidade técnica da execução, a confiabilidade da equipe, o cumprimento de prazos e a segurança do trabalho são fatores que impactam diretamente a produtividade e os custos operacionais de longo prazo. A <strong>{empresa}</strong> entende essa realidade e construiu ao longo de mais de uma década um modelo de atuação que coloca esses valores no centro de tudo.</p>

<h3>A importância do {kw} de qualidade em {loc}</h3>
<p>Um serviço de {kw_lower} executado com rigor técnico em {loc} representa muito mais do que uma manutenção ou instalação pontual. Representa a garantia de que os ativos industriais da sua empresa terão máxima disponibilidade, menor taxa de falhas e maior longevidade. Cada real investido em {kw_lower} profissional se multiplica em eficiência operacional e redução de custos com retrabalho e paradas emergenciais.</p>

<h3>Nossa estrutura para atender {loc}</h3>
<p>A {empresa} mantém em {loc} e região uma estrutura preparada para atender demandas de diferentes escalas:</p>
<ul>
  <li>Equipe técnica própria com especialistas em {kw_lower}</li>
  <li>Veículos equipados para deslocamento rápido até {loc}</li>
  <li>Estoque de materiais e componentes para agilizar a execução</li>
  <li>Ferramentas e equipamentos calibrados e certificados</li>
  <li>Sistema de gestão de projetos com rastreamento em tempo real</li>
  <li>Suporte técnico por telefone e WhatsApp para emergências</li>
</ul>

<h3>Manutenção preventiva: o melhor investimento para indústrias em {loc}</h3>
<p>Entre os serviços de {kw_lower} que a {empresa} oferece em {loc}, a manutenção preventiva merece destaque especial. Estudos do setor industrial apontam que cada real investido em prevenção evita de seis a oito reais em manutenção corretiva emergencial. Desenvolvemos planos de manutenção preventiva personalizados para cada cliente em {loc}, com cronograma definido, check-lists técnicos e histórico detalhado de todas as intervenções realizadas.</p>

<h3>Conformidade com a NR-12 em {loc}</h3>
<p>A Norma Regulamentadora NR-12 estabelece requisitos mínimos para a prevenção de acidentes e doenças do trabalho nas fases de projeto e utilização de máquinas e equipamentos. A {empresa} realiza em {loc} todos os serviços de {kw_lower} em total conformidade com a NR-12, garantindo que os equipamentos da sua empresa atendam aos requisitos legais e estejam seguros para operação. Isso protege seus colaboradores e blindam a empresa contra autuações e passivos trabalhistas.</p>

<h3>Histórico comprovado em {loc} e região</h3>
<p>Ao longo dos anos, a {empresa} acumulou um portfólio expressivo de projetos de {kw_lower} em {loc} e nas cidades vizinhas do oeste paranaense. Clientes dos setores alimentício, madeireiro, metalúrgico e de construção civil atestam a qualidade, a pontualidade e o profissionalismo da nossa equipe. Esse histórico comprovado é o nosso maior diferencial competitivo.</p>

<h3>Como solicitar {kw} em {loc}</h3>
<p>O processo é simples e sem burocracia: entre em contato pelo <strong>{telefone}</strong> ou pelo WhatsApp, descreva brevemente sua necessidade e nossa equipe agendará uma visita técnica gratuita em {loc}. Em seguida, apresentamos orçamento detalhado e, após aprovação, iniciamos a execução no prazo combinado. Atendemos {loc} de {horario}.</p>""",

"""<p>A <strong>{empresa}</strong> é reconhecida no mercado industrial do oeste paranaense como referência em <strong>{kw_lower}</strong>. Em <strong>{loc}</strong>, nossa presença se traduz em projetos executados com alto padrão técnico, equipe própria certificada e total comprometimento com os resultados do cliente. Mas o que realmente nos diferencia não é apenas o que fazemos — é como fazemos.</p>

<h3>Diagnóstico técnico gratuito em {loc}</h3>
<p>Antes de qualquer proposta, a {empresa} realiza uma visita técnica gratuita em {loc} para entender profundamente a necessidade do cliente. Essa etapa é fundamental: permite identificar com precisão o escopo do serviço de {kw_lower}, mapear riscos, definir metodologia e elaborar um orçamento que reflita a realidade do projeto — sem surpresas no meio do caminho.</p>

<h3>Execução com equipe própria em {loc}</h3>
<p>Ao contrário de muitas empresas do setor que terceirizam a execução, a {empresa} realiza todos os serviços de {kw_lower} em {loc} com equipe própria. Isso significa:</p>
<ul>
  <li>Controle de qualidade direto em cada etapa da execução</li>
  <li>Comunicação ágil e transparente com o cliente em {loc}</li>
  <li>Responsabilidade total e garantia formal sobre o resultado</li>
  <li>Rastreabilidade completa do projeto com documentação técnica</li>
  <li>Menor risco de retrabalho e maior previsibilidade de prazo</li>
</ul>

<h3>Normas e certificações aplicadas em {loc}</h3>
<p>A execução de {kw_lower} em ambiente industrial requer conhecimento técnico aprofundado das normas regulamentadoras. A {empresa} atua em {loc} com profissionais certificados nas principais normas do setor:</p>
<ul>
  <li><strong>NR-10:</strong> Segurança em instalações e serviços em eletricidade</li>
  <li><strong>NR-12:</strong> Segurança no trabalho em máquinas e equipamentos</li>
  <li><strong>NR-33:</strong> Segurança e saúde nos trabalhos em espaços confinados</li>
  <li><strong>NR-35:</strong> Trabalho em altura com uso de EPI e técnicas adequadas</li>
</ul>

<h3>Planejamento estratégico de manutenção para {loc}</h3>
<p>Para indústrias em {loc} que buscam otimizar seus custos operacionais, a {empresa} oferece o serviço de planejamento estratégico de manutenção. Analisamos o histórico de falhas, o perfil operacional dos equipamentos e as metas de produção para definir a melhor estratégia de {kw_lower}: preventiva, preditiva ou combinada. Esse planejamento resulta em maior disponibilidade dos ativos e redução significativa de custos de manutenção.</p>

<h3>Atendimento de emergência em {loc}</h3>
<p>Paradas de produção não avisam. Por isso, a {empresa} mantém um canal de atendimento de emergência para clientes em {loc} e região. Ao detectar uma falha ou necessidade urgente de {kw_lower}, entre em contato pelo <strong>{telefone}</strong> ou WhatsApp e nossa equipe avaliará a situação e providenciará a mobilização mais rápida possível para minimizar o impacto na sua produção.</p>

<p>Não espere a próxima falha para entrar em contato. Solicite hoje mesmo seu diagnóstico técnico gratuito e descubra como a {empresa} pode contribuir para a eficiência e a segurança da sua operação industrial em {loc}.</p>""",

"""<p>No cenário industrial do oeste paranaense, a escolha do fornecedor de <strong>{kw_lower}</strong> em <strong>{loc}</strong> é uma decisão estratégica. Empresas que investem em parceiros técnicos confiáveis para {kw_lower} experimentam menor taxa de paradas não planejadas, maior vida útil dos equipamentos e equipes mais seguras e produtivas. A <strong>{empresa}</strong> foi construída para ser esse parceiro — confiável, técnico e comprometido.</p>

<h3>Fundamentos técnicos do {kw} em {loc}</h3>
<p>O serviço de {kw_lower} em {loc} exige domínio de múltiplas disciplinas técnicas: mecânica, elétrica, soldagem, caldeiraria, hidráulica e, em muitos casos, instrumentação industrial. A {empresa} reúne em sua equipe profissionais especializados em cada uma dessas áreas, o que permite oferecer soluções integradas e completas para indústrias de {loc} sem a necessidade de múltiplos fornecedores.</p>

<h3>Vantagens econômicas do {kw} profissional em {loc}</h3>
<p>Investir em {kw_lower} profissional em {loc} traz benefícios econômicos tangíveis e mensuráveis:</p>
<ul>
  <li><strong>Redução de paradas emergenciais:</strong> manutenção preventiva bem executada pode reduzir paradas não planejadas em até 70%.</li>
  <li><strong>Maior vida útil dos equipamentos:</strong> intervenções técnicas corretas prolongam significativamente a operação dos ativos.</li>
  <li><strong>Conformidade legal:</strong> evita multas e autuações relacionadas a descumprimento de normas regulamentadoras.</li>
  <li><strong>Eficiência energética:</strong> equipamentos bem mantidos consomem menos energia e operam com maior rendimento.</li>
  <li><strong>Segurança dos colaboradores:</strong> reduz acidentes de trabalho e os custos humanos e financeiros associados.</li>
</ul>

<h3>Especialidades da {empresa} em {loc}</h3>
<p>Em {loc}, a {empresa} oferece um portfólio completo de serviços industriais que vai muito além do {kw_lower}. Nossa atuação abrange montagem eletromecânica, manutenção preventiva e corretiva, fabricação e montagem de estruturas metálicas, caldeiraria e soldagem industrial, pintura industrial (epóxi, anticorrosiva, piso), instalações elétricas e hidráulicas industriais e obras de infraestrutura industrial. Essa integração de serviços permite que o cliente em {loc} encontre em uma única empresa tudo o que precisa para manter sua planta em pleno funcionamento.</p>

<h3>Gestão de projetos com transparência total em {loc}</h3>
<p>Na {empresa}, cada projeto de {kw_lower} em {loc} é gerenciado com ferramentas de controle que garantem total transparência para o cliente. Desde o cronograma de execução até os relatórios técnicos de cada intervenção, o cliente tem acesso completo ao andamento do projeto e pode acompanhar cada etapa em tempo real.</p>

<h3>Contato e orçamento para {loc}</h3>
<p>A {empresa} está pronta para atender sua indústria em {loc}. Entre em contato agora pelo <strong>{telefone}</strong>, pelo WhatsApp ou visite nosso site para solicitar seu diagnóstico técnico gratuito. Nossa equipe responderá rapidamente e agendará a visita técnica mais conveniente para você. Atendemos {loc} e toda a região oeste do {estado} de {horario}.</p>""",
]

# ── Rodapé HTML ────────────────────────────────────────────────────────────────

def build_footer(cidade_nome, is_medianeira=False):
    links_uteis = LINKS_UTEIS_MEDIANEIRA if is_medianeira else LINKS_UTEIS_GENERICOS
    links_html = "\n".join(
        f'<li><a href="{url}" rel="nofollow noopener noreferrer" target="_blank">{nome}</a></li>'
        for nome, url in links_uteis
    )
    return f"""
  <footer id="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <a href="index.html" class="logo">Eco <span>Instalações</span></a>
          <p id="footer-desc">{EMPRESA} — soluções completas em montagem, manutenção e estruturas metálicas para a indústria do oeste paranaense.</p>
        </div>
        <div class="footer-col">
          <h4>Serviços</h4>
          <ul>
            <li><a href="index.html#servicos">Montagem Industrial</a></li>
            <li><a href="index.html#servicos">Manutenção Industrial</a></li>
            <li><a href="index.html#servicos">Estruturas Metálicas</a></li>
            <li><a href="index.html#servicos">Caldeiraria e Soldagem</a></li>
            <li><a href="index.html#servicos">Pintura Industrial</a></li>
            <li><a href="index.html#servicos">Hidráulica Industrial</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Navegação</h4>
          <ul>
            <li><a href="index.html">Página Inicial</a></li>
            <li><a href="mapa-do-site.html">Mapa do Site</a></li>
            <li><a href="index.html#sobre">Sobre Nós</a></li>
            <li><a href="index.html#depoimentos">Depoimentos</a></li>
            <li><a href="index.html#localizacao">Localização</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Contato</h4>
          <ul class="footer-info">
            <li>📞 {TELEFONE}</li>
            <li>📍 {cidade_nome} — {ESTADO}</li>
          </ul>
          <h4 style="margin-top:1.2rem">Horário</h4>
          <ul>
            <li>Segunda a Sábado</li>
            <li>07:00 às 12:00</li>
            <li>14:00 às 20:00</li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Links Úteis</h4>
          <ul>{links_html}</ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2025 {EMPRESA}. Todos os direitos reservados.</p>
      </div>
    </div>
  </footer>"""

# ── Template HTML ──────────────────────────────────────────────────────────────

def build_page(slug, meta_title, meta_desc, meta_keys, cidade_nome, loc_label,
               kw, kw_lower, hero_desc, about_html, features_html,
               seo_h2, seo_body, interlinking_html, is_medianeira=False,
               avenida_nome=None):

    footer_html = build_footer(cidade_nome, is_medianeira)
    avenida_badge = f" — {avenida_nome}" if avenida_nome else ""

    return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{meta_title}</title>
  <meta name="description" content="{meta_desc}">
  <meta name="keywords" content="{meta_keys}">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="{DOMINIO}/{slug}.html">
  <meta property="og:title" content="{meta_title}">
  <meta property="og:description" content="{meta_desc}">
  <meta property="og:type" content="website">
  <meta property="og:url" content="{DOMINIO}/{slug}.html">
  <meta property="og:locale" content="pt_BR">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <header id="site-header">
    <div class="container header-inner">
      <a href="index.html" class="logo">Eco <span>Instalações</span></a>
      <nav id="nav-menu" role="navigation" aria-label="Menu principal">
        <a href="index.html#sobre">Sobre</a>
        <a href="index.html#servicos">Serviços</a>
        <a href="index.html#depoimentos">Depoimentos</a>
        <a href="index.html#localizacao">Localização</a>
        <a href="mapa-do-site.html">Mapa do Site</a>
        <a href="https://wa.me/{WHATSAPP}?text=Ol%C3%A1%21+Vim+pelo+site+e+gostaria+de+um+or%C3%A7amento." class="nav-cta" target="_blank" rel="noopener noreferrer">Orçamento Grátis</a>
      </nav>
      <button id="menu-toggle" aria-label="Abrir menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>
  </header>

  <section id="hero">
    <div class="container hero-inner">
      <div class="hero-content">
        <span class="hero-label">{loc_label}{avenida_badge} — {ESTADO}</span>
        <h1 id="hero-title" class="hero-title">{kw} em {loc_label}</h1>
        <p id="hero-desc" class="hero-desc">{hero_desc}</p>
        <div class="hero-buttons">
          <a href="https://wa.me/{WHATSAPP}?text=Ol%C3%A1%21+Vim+pelo+site+e+gostaria+de+um+or%C3%A7amento." class="btn btn-primary" target="_blank" rel="noopener noreferrer">Solicitar Orçamento</a>
          <a href="index.html#servicos" class="btn btn-outline">Ver Serviços</a>
        </div>
      </div>
      <div class="hero-visual" aria-hidden="true">
        <div class="hero-stat"><span class="hero-stat-icon">🏭</span><div><div class="hero-stat-num">+500</div><div class="hero-stat-label">Projetos Executados</div></div></div>
        <div class="hero-stat"><span class="hero-stat-icon">🔩</span><div><div class="hero-stat-num">+10</div><div class="hero-stat-label">Anos de Experiência</div></div></div>
        <div class="hero-stat"><span class="hero-stat-icon">📍</span><div><div class="hero-stat-num">39+</div><div class="hero-stat-label">Cidades Atendidas</div></div></div>
        <div class="hero-stat"><span class="hero-stat-icon">⭐</span><div><div class="hero-stat-num">100%</div><div class="hero-stat-label">Clientes Satisfeitos</div></div></div>
      </div>
    </div>
  </section>

  <section id="sobre">
    <div class="container about-inner">
      <div class="about-visual animate-on-scroll">
        <div class="about-badge"><span>🏆</span><span>Referência em {kw} no PR</span></div>
        <ul class="about-list">
          <li>Equipe técnica própria e certificada</li>
          <li>Atendimento em {loc_label} e região oeste do PR</li>
          <li>Prazos rigorosamente respeitados</li>
          <li>NR-10, NR-12, NR-33 e NR-35</li>
          <li>Garantia formal em todos os serviços</li>
          <li>Diagnóstico técnico gratuito em {loc_label}</li>
        </ul>
      </div>
      <div class="about-text animate-on-scroll">
        <span class="section-label">Sobre a Empresa</span>
        <h2 id="about-title" class="section-title">{EMPRESA} em {loc_label}</h2>
        <div id="about-desc">{about_html}</div>
        <a href="https://wa.me/{WHATSAPP}?text=Ol%C3%A1%21+Quero+saber+mais+sobre+{kw_lower.replace(' ', '+')}+em+{loc_label.replace(' ', '+')}." class="btn btn-primary" target="_blank" rel="noopener noreferrer" style="margin-top:1.5rem">Fale Conosco</a>
      </div>
    </div>
  </section>

  <section id="servicos">
    <div class="container">
      <div class="features-header animate-on-scroll">
        <span class="section-label">Especialidades</span>
        <h2 id="features-title" class="section-title">Nossos Serviços em {loc_label}</h2>
        <p class="section-subtitle">Soluções completas em {kw_lower} para a indústria de {loc_label} e região.</p>
      </div>
      <div id="features-list">{features_html}</div>
    </div>
  </section>

  <section id="conteudo-seo">
    <div class="container conteudo-seo">
      <h2>{seo_h2}</h2>
      {seo_body}
    </div>
  </section>

  <section class="interlinking">
    <div class="container">
      <h2 class="section-title">Veja Também</h2>
      <div class="interlinking-grid">{interlinking_html}</div>
    </div>
  </section>

  {footer_html}

  <a id="whatsapp-float" href="https://wa.me/{WHATSAPP}?text=Ol%C3%A1%21+Vim+pelo+site+e+gostaria+de+um+or%C3%A7amento." aria-label="WhatsApp" target="_blank" rel="noopener noreferrer">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
  </a>

  <script>window.skipInjection = ['hero', 'about', 'features'];</script>
  <script src="js/colors.js"></script>
  <script src="js/content.js"></script>
  <script src="js/maps.js"></script>
  <script src="js/main.js"></script>

</body>
</html>"""

# ── Gerador principal ──────────────────────────────────────────────────────────

def build_features_html(kw, loc, features):
    cards = []
    for title_t, desc_t in features:
        t = fmt(title_t, kw=kw, kw_lower=kw.lower(), loc=loc, estado=ESTADO, empresa=EMPRESA)
        d = fmt(desc_t,  kw=kw, kw_lower=kw.lower(), loc=loc, estado=ESTADO, empresa=EMPRESA)
        cards.append(f'<div class="feature-card"><h3>{t}</h3><p>{d}</p></div>')
    return "\n".join(cards)

def build_about_html(paras, kw, loc):
    out = []
    for p in paras:
        out.append("<p>" + fmt(p, kw=kw, kw_lower=kw.lower(), loc=loc,
                               estado=ESTADO, empresa=EMPRESA) + "</p>")
    return "\n".join(out)

def build_interlinking(all_pages, current_slug, n=8):
    cands = [(s, t) for s, t in all_pages if s != current_slug]
    sel   = random.sample(cands, min(n, len(cands)))
    return "\n".join(
        f'<div class="interlinking-item"><a href="{s}.html">{t}</a></div>'
        for s, t in sel
    )

def generate():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir    = os.path.dirname(current_dir)
    site_dir    = os.path.join(base_dir, 'site')
    pages_file  = os.path.join(current_dir, '9_paginas.md')

    os.makedirs(site_dir, exist_ok=True)

    # Ler páginas kw+cidade
    with open(pages_file, 'r', encoding='utf-8') as f:
        kw_cidade_titles = [l.strip() for l in f if l.strip()]

    # Montar lista de cidades
    cidades_list = list(AVENIDAS.keys())

    # Construir lista de páginas de avenida (kw principal = "Montagem E Manutenção Industrial")
    KW_AVENIDA = "Montagem E Manutenção Industrial"
    avenida_titles = []
    for cidade in cidades_list:
        for av in AVENIDAS[cidade]:
            title = f"{KW_AVENIDA} Avenida {av} {cidade}"
            avenida_titles.append((title, cidade, av))

    # Todos os slugs para interlinking
    all_slugs_titles = [(slugify(t), t) for t in kw_cidade_titles]
    all_slugs_titles += [(slugify(t), t) for t, c, a in avenida_titles]

    total_kw   = len(kw_cidade_titles)
    total_av   = len(avenida_titles)
    total_all  = total_kw + total_av

    print(f"Total de páginas a gerar: {total_all} ({total_kw} kw+cidade + {total_av} avenidas)")

    # ── Gerar páginas kw+cidade ────────────────────────────────────────────────
    for idx, title in enumerate(kw_cidade_titles):
        parts  = title.rsplit(' ', 1)
        cidade_nome = parts[-1] if len(parts) == 2 else ESTADO
        kw     = parts[0]  if len(parts) == 2 else title
        slug   = slugify(title)
        loc    = cidade_nome
        is_med = (cidade_nome.lower() == "medianeira" or
                  slugify(cidade_nome) == "medianeira")

        random.seed(idx * 11 + 7)

        hero_d   = fmt(HERO_DESCS[idx % len(HERO_DESCS)],
                       kw=kw, kw_lower=kw.lower(), loc=loc,
                       estado=ESTADO, empresa=EMPRESA, telefone=TELEFONE)
        about_p  = ABOUT_PARAS[idx % len(ABOUT_PARAS)]
        seo_h2_t = SEO_H2[idx % len(SEO_H2)]
        seo_b_t  = SEO_BODIES[idx % len(SEO_BODIES)]

        feat_pool = FEATURES_POOL[:]
        random.shuffle(feat_pool)
        feats = feat_pool[:4]

        about_html   = build_about_html(about_p, kw, loc)
        features_html = build_features_html(kw, loc, feats)
        seo_h2_str   = fmt(seo_h2_t, kw=kw, kw_lower=kw.lower(), loc=loc, empresa=EMPRESA)
        seo_body_str = fmt(seo_b_t,  kw=kw, kw_lower=kw.lower(), loc=loc,
                           estado=ESTADO, empresa=EMPRESA, telefone=TELEFONE, horario=HORARIO)
        interlink    = build_interlinking(all_slugs_titles, slug, n=8)

        meta_title = f"{kw} em {loc} | {EMPRESA}"
        meta_desc  = f"Contrate {kw.lower()} em {loc} com a {EMPRESA}. Equipe certificada, orçamento gratuito e garantia nos serviços. Ligue: {TELEFONE}."
        meta_keys  = f"{kw.lower()}, {kw.lower()} {loc}, empresa {kw.lower()} {loc}, montagem industrial {loc}, manutenção industrial {loc}"

        html = build_page(
            slug=slug, meta_title=meta_title, meta_desc=meta_desc, meta_keys=meta_keys,
            cidade_nome=cidade_nome, loc_label=loc, kw=kw, kw_lower=kw.lower(),
            hero_desc=hero_d, about_html=about_html, features_html=features_html,
            seo_h2=seo_h2_str, seo_body=seo_body_str, interlinking_html=interlink,
            is_medianeira=is_med
        )

        with open(os.path.join(site_dir, f"{slug}.html"), 'w', encoding='utf-8') as f:
            f.write(html)

        if (idx + 1) % 200 == 0 or (idx + 1) == total_kw:
            print(f"  kw+cidade: {idx+1}/{total_kw}")

    # ── Gerar páginas de avenida ───────────────────────────────────────────────
    for idx, (title, cidade_nome, av_nome) in enumerate(avenida_titles):
        slug   = slugify(title)
        kw     = KW_AVENIDA
        loc    = f"Avenida {av_nome}, {cidade_nome}"
        is_med = (slugify(cidade_nome) == "medianeira")

        random.seed(idx * 13 + 3 + total_kw)

        # Conteúdo diferenciado para páginas de avenida
        hero_d_t = HERO_DESCS[(idx + 3) % len(HERO_DESCS)]
        hero_d   = fmt(hero_d_t, kw=kw, kw_lower=kw.lower(), loc=loc,
                       estado=ESTADO, empresa=EMPRESA, telefone=TELEFONE)
        about_p  = ABOUT_PARAS[(idx + 2) % len(ABOUT_PARAS)]
        seo_h2_t = SEO_H2[(idx + 5) % len(SEO_H2)]
        seo_b_t  = SEO_BODIES[(idx + 1) % len(SEO_BODIES)]

        feat_pool = FEATURES_POOL[:]
        random.shuffle(feat_pool)
        feats = feat_pool[:4]

        about_html   = build_about_html(about_p, kw, loc)
        features_html = build_features_html(kw, loc, feats)
        seo_h2_str   = fmt(seo_h2_t, kw=kw, kw_lower=kw.lower(), loc=loc, empresa=EMPRESA)
        seo_body_str = fmt(seo_b_t,  kw=kw, kw_lower=kw.lower(), loc=loc,
                           estado=ESTADO, empresa=EMPRESA, telefone=TELEFONE, horario=HORARIO)
        interlink    = build_interlinking(all_slugs_titles, slug, n=8)

        meta_title = f"{kw} na {av_nome}, {cidade_nome} | {EMPRESA}"
        meta_desc  = f"Serviços de {kw.lower()} na Avenida {av_nome} em {cidade_nome}. {EMPRESA} — equipe certificada, orçamento gratuito. {TELEFONE}."
        meta_keys  = f"{kw.lower()} {cidade_nome}, {kw.lower()} avenida {av_nome.lower()}, empresa industrial {cidade_nome}, montagem industrial {cidade_nome}"

        html = build_page(
            slug=slug, meta_title=meta_title, meta_desc=meta_desc, meta_keys=meta_keys,
            cidade_nome=cidade_nome, loc_label=loc, kw=kw, kw_lower=kw.lower(),
            hero_desc=hero_d, about_html=about_html, features_html=features_html,
            seo_h2=seo_h2_str, seo_body=seo_body_str, interlinking_html=interlink,
            is_medianeira=is_med, avenida_nome=av_nome
        )

        with open(os.path.join(site_dir, f"{slug}.html"), 'w', encoding='utf-8') as f:
            f.write(html)

        if (idx + 1) % 50 == 0 or (idx + 1) == total_av:
            print(f"  avenidas: {idx+1}/{total_av}")

    # ── Atualizar mapa do site ─────────────────────────────────────────────────
    print("Gerando mapa-do-site.html...")
    all_titles_for_map = kw_cidade_titles + [t for t, c, a in avenida_titles]
    all_slugs_map      = [(slugify(t), t) for t in all_titles_for_map]

    links_html = "\n".join(
        f'<div class="link-item"><a href="{s}.html">{t}</a></div>'
        for s, t in all_slugs_map
    )
    mapa_html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mapa do Site — {EMPRESA}</title>
  <style>
    body{{font-family:'Segoe UI',sans-serif;padding:40px;max-width:1200px;margin:0 auto;background:#f4f4f9;color:#333}}
    h1{{border-bottom:3px solid #F97316;padding-bottom:15px;color:#0F172A;text-align:center}}
    .links-container{{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:15px;margin-top:30px}}
    .link-item{{background:#fff;padding:10px 15px;border-radius:8px;box-shadow:0 2px 5px rgba(0,0,0,.05);transition:transform .2s}}
    .link-item:hover{{transform:translateY(-3px);box-shadow:0 4px 10px rgba(0,0,0,.1)}}
    a{{text-decoration:none;color:#F97316;font-size:14px;font-weight:500}}
    a:hover{{color:#ea6c0a}}
    .footer-links{{margin-bottom:30px;padding:20px;background:#e9ecef;border-radius:8px;text-align:center}}
    .footer-links a{{margin:0 15px;font-size:16px;font-weight:bold;text-transform:uppercase}}
  </style>
</head>
<body>
  <h1>Mapa do Site — {EMPRESA}</h1>
  <div class="footer-links">
    <a href="index.html">Página Inicial</a>
    <a href="mapa-do-site.html">Mapa do Site</a>
  </div>
  <div class="links-container">
    {links_html}
  </div>
</body>
</html>"""

    with open(os.path.join(site_dir, 'mapa-do-site.html'), 'w', encoding='utf-8') as f:
        f.write(mapa_html)

    # ── Atualizar sitemap.xml ─────────────────────────────────────────────────
    print("Gerando sitemap.xml...")
    xml_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
        f'  <url><loc>{DOMINIO}/index.html</loc><changefreq>daily</changefreq><priority>1.0</priority></url>',
        f'  <url><loc>{DOMINIO}/mapa-do-site.html</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>',
    ]
    for s, _ in all_slugs_map:
        xml_lines.append(f'  <url><loc>{DOMINIO}/{s}.html</loc><changefreq>monthly</changefreq><priority>0.6</priority></url>')
    xml_lines.append('</urlset>')

    with open(os.path.join(site_dir, 'sitemap.xml'), 'w', encoding='utf-8') as f:
        f.write("\n".join(xml_lines))

    total_files = total_all + 2
    print(f"\n✅ Concluído! {total_files} arquivos gerados em {site_dir}")
    print(f"   {total_kw} páginas kw+cidade")
    print(f"   {total_av} páginas avenida")
    print(f"   mapa-do-site.html + sitemap.xml atualizados")

if __name__ == "__main__":
    generate()
