# Procedimento de Criação do Site (Do Zero)

Este guia detalha o processo completo para gerar o site da Eco Instalações Industriais.

## Etapa 1: Configuração Manual

1. **Dados da Empresa**: Edite `markups/0_customizacao.md` com Nome, Telefone, Cores, etc.
2. **Locais de Atendimento**: Edite `markups/9_locais.md` — uma cidade por linha.
3. **Palavras-Chave**: Edite `markups/9_palavras-chave.md` — um serviço por linha.

## Etapa 2: Geração de Dados (Scripts Python)

Execute no terminal na ordem:

```bash
python markups/2_mix_palavras-chave_locais.py
python markups/4_criar_grupos_paginas.py
python markups/3_criar_mapa_do_site.py
```

## Etapa 3: Personalizar Template e Página Inicial

- Edite `site/js/content.js`, `site/js/colors.js` e `site/js/maps.js` com os dados de `markups/0_customizacao.md`.
- Edite `site/index.html` (seções Hero e SEO).

## Etapa 4: Criar Páginas de Conteúdo

- Abra `markups/grupos-de-paginas.md` e processe cada grupo conforme `markups/5_criar_paginas.md`.

## Etapa 5: Interlinking SEO

```bash
python markups/6_interlinking.py
```

## Etapa 6: Verificação Final

1. Abra `site/index.html` no navegador.
2. Teste o botão de WhatsApp.
3. Verifique o mapa no `site/mapa-do-site.html`.
4. Confirme que as páginas internas têm conteúdo único.
