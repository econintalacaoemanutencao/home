"""
Script responsável por gerar combinações de SEO misturando palavras-chave e locais.
Lê '9_palavras-chave.md' e '9_locais.md' e gera '9_paginas.md'.
"""
import os

def mix_seo():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    keywords_path = os.path.join(base_dir, '9_palavras-chave.md')
    locais_path = os.path.join(base_dir, '9_locais.md')
    output_path = os.path.join(base_dir, '9_paginas.md')

    if not os.path.exists(keywords_path):
        print(f"Erro: Arquivo {keywords_path} não encontrado.")
        return

    with open(keywords_path, 'r', encoding='utf-8') as f:
        keywords = [line.strip().rstrip(',').title() for line in f if line.strip()]

    with open(keywords_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(keywords) + '\n')

    if not os.path.exists(locais_path):
        print(f"Erro: Arquivo {locais_path} não encontrado.")
        return

    with open(locais_path, 'r', encoding='utf-8') as f:
        locais = []
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith('#'):
                continue
            locais.append(line.title())

    with open(locais_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(locais) + '\n')

    paginas = []
    for kw in keywords:
        for local in locais:
            paginas.append(f"{kw} {local}")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(paginas))
        f.write('\n')

    print(f"Sucesso! Geradas {len(paginas)} combinações em {output_path}")

if __name__ == "__main__":
    mix_seo()
