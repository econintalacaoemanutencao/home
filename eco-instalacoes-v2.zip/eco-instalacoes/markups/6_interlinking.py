import os
import random
import re

def get_links_from_sitemap(sitemap_path):
    links = []
    if not os.path.exists(sitemap_path):
        print(f"Erro: {sitemap_path} não encontrado.")
        return links

    with open(sitemap_path, 'r', encoding='utf-8') as f:
        content = f.read()
        matches = re.findall(r'<div class="link-item"><a href="([^"]+)">([^<]+)</a></div>', content)
        for href, text in matches:
            links.append({'href': href, 'text': text})
    return links

def inject_interlinking():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(current_dir)
    site_dir = os.path.join(base_dir, 'site')

    sitemap_file = os.path.join(site_dir, 'mapa-do-site.html')
    all_links = get_links_from_sitemap(sitemap_file)

    if not all_links:
        print("Nenhum link encontrado no mapa do site.")
        return

    html_files = [f for f in os.listdir(site_dir) if f.endswith('.html') and f != 'index.html' and f != 'mapa-do-site.html']

    for filename in html_files:
        file_path = os.path.join(site_dir, filename)

        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        if '<!-- Interlinking -->' in content:
            print(f"Interlinking já presente em {filename}, pulando...")
            continue

        available_links = [l for l in all_links if l['href'] != filename]

        selected_links = random.sample(available_links, min(6, len(available_links)))

        interlinking_html = "\n    <!-- Interlinking -->\n"
        interlinking_html += '    <section class="interlinking">\n'
        interlinking_html += '        <div class="container">\n'
        interlinking_html += '            <h2 class="section-title">Veja Também</h2>\n'
        interlinking_html += '            <div class="interlinking-grid">\n'

        for link in selected_links:
            interlinking_html += f'                <div class="interlinking-item">\n'
            interlinking_html += f'                    <a href="{link["href"]}">{link["text"]}</a>\n'
            interlinking_html += '                </div>\n'

        interlinking_html += '            </div>\n'
        interlinking_html += '        </div>\n'
        interlinking_html += '    </section>\n'

        if '<!-- Footer -->' in content:
            new_content = content.replace('<!-- Footer -->', interlinking_html + '    <!-- Footer -->')
        elif '<footer' in content:
            new_content = content.replace('<footer', interlinking_html + '    <footer')
        else:
            print(f"Não foi possível encontrar o rodapé em {filename}")
            continue

        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Interlinking injetado em {filename}")

if __name__ == "__main__":
    inject_interlinking()
