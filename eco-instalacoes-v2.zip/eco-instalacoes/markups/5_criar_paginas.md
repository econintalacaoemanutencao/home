# Geração de Páginas SEO

**Objetivo**: Criar páginas para o grupo selecionado em `grupos-de-paginas.md`, duplicando a index e personalizando completamente o conteúdo principal.

**Importante**: Todo conteúdo das seções Hero, Sobre, Serviços e SEO deve ser **100% ORIGINAL E ÚNICO** para cada página.

**CRÍTICO**:
- É ESTRITAMENTE PROIBIDO copiar ou apenas trocar o nome da cidade em textos de outras páginas.
- Cada página deve ter textos escritos do zero para as seções Hero, Sobre e Serviços.
- Varie a abordagem: rapidez, segurança, tecnologia, experiência — sempre relevante ao serviço e local.

## Fluxo de Execução (Por Página)

1. **Copiar e Renomear**: Leia `site/index.html`. Salve uma cópia em `site/{slug-da-pagina}.html`.

2. **Gerar Conteúdo Único**:
   - `meta_title`: Título da página (ex: "Montagem Industrial Foz do Iguaçu")
   - `meta_desc`: Descrição chamativa (até 160 caracteres)
   - `meta_keys`: 5-10 palavras-chave
   - `hero_h1`: Exatamente igual ao `meta_title`
   - `hero_subtitle`: Subtítulo curto e único
   - `hero_desc`: Texto comercial (~39 palavras), único
   - `about_content`: 2-3 parágrafos únicos sobre a empresa focados no contexto da página
   - `features_list`: 3-4 diferenciais/serviços com títulos e descrições únicas
   - `seo_h2`: Título técnico (H2)
   - `seo_content`: Artigo técnico com 300 palavras em HTML (`<p>`, `<h3>`, `<ul>`)

3. **Inserção no Arquivo**:
   - Atualize `<title>`, `<meta name="description">`, `<meta name="keywords">`
   - Substitua `h1#hero-title`, `h2#hero-subtitle`, `#hero-desc`
   - Substitua `div#about-desc` com parágrafos `<p>`
   - Substitua `div#features-list` com cards:
     ```html
     <div class="feature-card">
         <h3>Título do Serviço</h3>
         <p>Descrição única do serviço.</p>
     </div>
     ```
   - Substitua seção SEO com `seo_h2` e `seo_content`

4. **Desativar Injeção JS (CRUCIAL)**: Antes dos scripts, adicione:
   ```html
   <script>
       window.skipInjection = ['hero', 'about', 'features'];
   </script>
   ```

**Regra de Ouro**: O conteúdo deve ser estático no HTML para garantir que o Google indexe texto único.
