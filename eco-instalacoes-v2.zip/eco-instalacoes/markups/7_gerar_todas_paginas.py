"""
7_gerar_todas_paginas.py
Gera todas as páginas SEO listadas em 9_paginas.md,
com conteúdo variado por keyword e cidade.
"""
import os
import re
import unicodedata
import random

# ── Helpers ────────────────────────────────────────────────────────────────────

def slugify(value):
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    value = re.sub(r'[^\w\s-]', '', value).strip().lower()
    return re.sub(r'[-\s]+', '-', value)

# ── Dados da empresa ───────────────────────────────────────────────────────────

EMPRESA      = "Eco Instalações Industriais"
TELEFONE     = "(45) 98832-0733"
WHATSAPP     = "5545988320733"
DOMINIO      = "https://ecoinstalacoesindustriais.com.br"
HORARIO      = "Segunda a Sábado, das 07h às 12h e das 14h às 20h"
ESTADO       = "Paraná"

# ── Pools de conteúdo variado ──────────────────────────────────────────────────

HERO_SUBTITLES = [
    "Soluções industriais com qualidade e segurança",
    "Excelência técnica para sua indústria",
    "Equipe especializada, resultado garantido",
    "Atendimento ágil e profissional no oeste do Paraná",
    "Do projeto à execução com total confiabilidade",
    "Segurança e eficiência em cada serviço",
    "Tecnologia e experiência a serviço da sua produção",
    "Comprometidos com o sucesso do seu negócio",
    "Precisão técnica e cumprimento de prazos",
    "Parceiro estratégico para a indústria paranaense",
]

HERO_DESCS = [
    "A {empresa} atua em {cidade} com soluções completas em {kw_lower}, garantindo qualidade, segurança e cumprimento de prazos para indústrias de todos os portes.",
    "Em {cidade}, a {empresa} é referência em {kw_lower}. Nossa equipe técnica certificada oferece diagnóstico gratuito e orçamento sem compromisso.",
    "Precisa de {kw_lower} em {cidade}? A {empresa} tem a experiência e a estrutura para atender sua demanda com agilidade e alto padrão técnico.",
    "Com mais de 10 anos no mercado, a {empresa} entrega serviços de {kw_lower} em {cidade} com equipe qualificada e foco em resultado.",
    "A {empresa} combina tecnologia e expertise para oferecer {kw_lower} de ponta em {cidade} e em toda a região oeste do {estado}.",
    "Sua indústria em {cidade} merece o melhor em {kw_lower}. A {empresa} garante execução técnica impecável e suporte completo do início ao fim.",
    "Somos especialistas em {kw_lower} e atendemos {cidade} com equipe própria, equipamentos modernos e total comprometimento com a qualidade.",
    "A {empresa} leva até {cidade} o que há de melhor em {kw_lower}: profissionais experientes, metodologia rigorosa e foco na satisfação do cliente.",
]

ABOUT_PARAS = [
    [
        "A <strong>{empresa}</strong> é uma empresa paranaense com sólida trajetória no segmento de montagem e manutenção industrial. Atuamos em {cidade} e em toda a região oeste do Paraná, oferecendo soluções técnicas completas para indústrias de diferentes portes e segmentos.",
        "Nossa equipe é composta por profissionais altamente qualificados em {kw_lower}, metalurgia, soldagem, instalações elétricas e hidráulica industrial. Cada projeto é tratado com máxima atenção aos detalhes e rigorosos padrões de segurança.",
        "Em {cidade}, somos reconhecidos pela seriedade, pontualidade e pela qualidade dos serviços entregues. Entre em contato e descubra como podemos contribuir para a eficiência da sua operação.",
    ],
    [
        "Fundada com o propósito de oferecer soluções industriais de alto nível, a <strong>{empresa}</strong> chegou a {cidade} para transformar a forma como as indústrias locais lidam com {kw_lower}.",
        "Nossa abordagem é técnica e humanizada: escutamos as necessidades do cliente, elaboramos um plano de ação detalhado e executamos cada etapa com precisão. Trabalhamos com normas NR10, NR12 e NR33 para garantir a segurança de todos.",
        "Com equipamentos modernos e profissionais certificados, a {empresa} é o parceiro que sua empresa em {cidade} precisa para crescer com segurança e eficiência.",
    ],
    [
        "A <strong>{empresa}</strong> atua há mais de uma década no mercado industrial do Paraná. Em {cidade}, já realizamos dezenas de projetos de {kw_lower} para clientes dos setores alimentício, madeireiro, metalúrgico e de construção civil.",
        "Nossa missão é simples: entregar o melhor serviço técnico possível, dentro do prazo e do orçamento acordado. Para isso, investimos continuamente na capacitação da nossa equipe e na atualização dos nossos equipamentos.",
        "Se você busca um fornecedor confiável de {kw_lower} em {cidade}, a {empresa} é a escolha certa. Solicite um orçamento gratuito agora mesmo.",
    ],
    [
        "Com presença consolidada no oeste paranaense, a <strong>{empresa}</strong> leva até {cidade} uma estrutura completa de {kw_lower}, com profissionais especializados e comprometidos com resultados.",
        "Acreditamos que cada cliente é único. Por isso, desenvolvemos soluções personalizadas que atendem às especificidades de cada operação industrial em {cidade}, sempre priorizando segurança, qualidade e eficiência.",
        "Nossa reputação foi construída projeto a projeto, cliente a cliente. Hoje somos referência em {kw_lower} no oeste do Paraná e orgulhamo-nos de um histórico de clientes satisfeitos em {cidade} e região.",
    ],
]

FEATURES_POOL = [
    ("Diagnóstico Técnico Gratuito",   "Avaliamos sua necessidade em {cidade} sem custos, identificando a melhor solução para {kw_lower} com agilidade e precisão."),
    ("Equipe Certificada",             "Profissionais com certificações NR10, NR12 e NR33, prontos para atuar com segurança em qualquer ambiente industrial em {cidade}."),
    ("Cumprimento de Prazos",          "Planejamento rigoroso e execução eficiente garantem que os serviços de {kw_lower} em {cidade} sejam concluídos no prazo combinado."),
    ("Atendimento Regional",           "Além de {cidade}, atendemos mais de 39 municípios do oeste do {estado}, com deslocamento rápido e suporte local."),
    ("Garantia nos Serviços",          "Todos os serviços de {kw_lower} realizados pela {empresa} em {cidade} têm garantia formal, assegurando sua tranquilidade."),
    ("Orçamento Transparente",         "Sem surpresas: apresentamos orçamento detalhado e claro antes de iniciar qualquer trabalho de {kw_lower} em {cidade}."),
    ("Equipamentos Modernos",          "Utilizamos ferramentas e equipamentos de última geração para garantir precisão e qualidade nos serviços em {cidade}."),
    ("Suporte Pós-Serviço",            "Nosso relacionamento com o cliente em {cidade} não termina na entrega. Oferecemos suporte técnico após a conclusão de cada projeto."),
    ("Normas de Segurança",            "Seguimos todas as normas regulamentadoras aplicáveis a {kw_lower}, protegendo colaboradores e patrimônio industrial em {cidade}."),
    ("Soluções Integradas",            "Da montagem à manutenção, passando por estruturas metálicas e pintura, oferecemos uma solução 360° para sua indústria em {cidade}."),
    ("Manutenção Preventiva",          "Desenvolvemos planos de manutenção preventiva em {cidade} que reduzem paradas inesperadas e maximizam a produtividade."),
    ("Execução Rápida",                "Mobilizamos equipe e recursos com agilidade para minimizar o tempo de parada da sua operação em {cidade}."),
]

SEO_H2_TEMPLATES = [
    "{kw} em {cidade}: Expertise que Faz a Diferença",
    "Por que a {empresa} é a Melhor Escolha para {kw} em {cidade}?",
    "{kw} em {cidade} — Soluções Completas para sua Indústria",
    "Entenda como Funciona o Serviço de {kw} em {cidade}",
    "{kw} em {cidade}: Qualidade Técnica e Confiabilidade",
    "Como Contratar {kw} em {cidade} com Segurança",
    "{kw} em {cidade}: Tudo que sua Empresa Precisa Saber",
    "Referência em {kw} no Oeste do Paraná — Atendemos {cidade}",
]

SEO_BODIES = [
    """
<p>A contratação de uma empresa especializada em <strong>{kw_lower}</strong> em <strong>{cidade}</strong> é fundamental para garantir a segurança, a eficiência e a longevidade dos ativos industriais. A <strong>{empresa}</strong> atua nesse segmento com uma equipe técnica de alto nível e equipamentos modernos, prontos para atender às demandas de indústrias de todos os portes.</p>
<h3>O que engloba o serviço de {kw} em {cidade}?</h3>
<p>O serviço de {kw_lower} envolve um conjunto de atividades técnicas que variam conforme a necessidade de cada cliente. Em {cidade}, a {empresa} realiza desde diagnósticos preliminares até a execução completa de projetos, passando por planejamento, mobilização de equipe e fornecimento de materiais quando necessário.</p>
<h3>Etapas do nosso processo</h3>
<ul>
  <li>Visita técnica e levantamento das necessidades em {cidade}</li>
  <li>Elaboração de proposta técnica e orçamento detalhado</li>
  <li>Planejamento da execução com cronograma definido</li>
  <li>Execução por equipe certificada com EPI completo</li>
  <li>Testes, comissionamento e entrega formal</li>
  <li>Suporte pós-serviço e relatório técnico</li>
</ul>
<p>Com esse processo estruturado, a {empresa} garante que cada projeto de {kw_lower} em {cidade} seja entregue com máxima qualidade, dentro do prazo e do orçamento acordado.</p>
<h3>Diferenciais competitivos em {cidade}</h3>
<p>O que nos diferencia das demais empresas que oferecem {kw_lower} em {cidade} é a combinação de experiência acumulada, equipe própria certificada e compromisso real com o cliente. Não terceirizamos etapas críticas — toda a execução é feita pela nossa equipe, garantindo controle de qualidade de ponta a ponta.</p>
<p>Ligue agora para <strong>{telefone}</strong> ou envie uma mensagem pelo WhatsApp e receba um orçamento gratuito para {kw_lower} em {cidade}.</p>
""",
    """
<p>Quando o assunto é <strong>{kw_lower}</strong> em <strong>{cidade}</strong>, a <strong>{empresa}</strong> se destaca pela qualidade técnica, pela agilidade no atendimento e pela transparência em todas as etapas do projeto. Com mais de uma década de experiência no oeste do {estado}, somos o parceiro ideal para sua indústria.</p>
<h3>Por que investir em {kw} profissional?</h3>
<p>Contratar uma empresa despreparada para {kw_lower} pode gerar custos muito maiores no médio prazo: paradas de produção, retrabalho, acidentes e danos a equipamentos. A {empresa} oferece um serviço técnico rigoroso que previne esses problemas e agrega valor real ao seu negócio em {cidade}.</p>
<h3>Setores atendidos em {cidade}</h3>
<ul>
  <li>Indústrias alimentícias e frigoríficos</li>
  <li>Metalúrgicas e empresas de estamparia</li>
  <li>Madeireiras e serrarias</li>
  <li>Empresas de construção civil e infraestrutura</li>
  <li>Indústrias plásticas e de embalagem</li>
  <li>Cooperativas e agroindústrias</li>
</ul>
<h3>Como solicitar {kw} em {cidade}?</h3>
<p>O processo é simples: entre em contato pelo <strong>{telefone}</strong> ou pelo WhatsApp, descreva sua necessidade e nossa equipe agendará uma visita técnica gratuita em {cidade}. Em seguida, apresentamos um orçamento detalhado e, após aprovação, iniciamos a execução conforme cronograma acordado.</p>
<p>A {empresa} atende {cidade} e mais de 39 municípios do oeste paranaense. Não deixe para depois — cada dia sem manutenção adequada é um risco para sua produção.</p>
""",
    """
<p>A <strong>{empresa}</strong> é reconhecida como referência em <strong>{kw_lower}</strong> no oeste do {estado}. Nosso atendimento em <strong>{cidade}</strong> combina rapidez, técnica e compromisso com a satisfação do cliente, características que nos tornam a escolha preferida das indústrias da região.</p>
<h3>Importância do {kw} bem executado</h3>
<p>Um serviço de {kw_lower} executado com rigor técnico impacta diretamente na produtividade, na segurança operacional e nos custos de manutenção futura. Em {cidade}, a {empresa} aplica metodologias comprovadas para garantir que cada entrega supere as expectativas do cliente.</p>
<h3>Nossa estrutura para atender {cidade}</h3>
<ul>
  <li>Equipe própria com técnicos especializados em {kw_lower}</li>
  <li>Veículos e equipamentos para deslocamento rápido até {cidade}</li>
  <li>Estoque de materiais e peças para agilizar a execução</li>
  <li>Ferramentas calibradas e certificadas</li>
  <li>Gestão de projeto com acompanhamento em tempo real</li>
</ul>
<h3>Segurança em primeiro lugar</h3>
<p>Todos os serviços de {kw_lower} realizados pela {empresa} em {cidade} seguem as normas regulamentadoras vigentes (NR10, NR12, NR33, entre outras). Nossa equipe utiliza EPI completo e segue procedimentos rigorosos de segurança, protegendo colaboradores, equipamentos e instalações do cliente.</p>
<p>Entre em contato agora: <strong>{telefone}</strong>. Atendemos {cidade} de {horario}.</p>
""",
    """
<p>Escolher o fornecedor certo de <strong>{kw_lower}</strong> em <strong>{cidade}</strong> pode ser a diferença entre uma operação eficiente e prejuízos evitáveis. A <strong>{empresa}</strong> reúne experiência, estrutura e profissionalismo para ser esse parceiro confiável para sua indústria.</p>
<h3>Vantagens de contratar a {empresa} em {cidade}</h3>
<ul>
  <li>Mais de 10 anos de experiência em {kw_lower}</li>
  <li>Equipe técnica própria e certificada</li>
  <li>Atendimento em {cidade} e toda a região oeste do {estado}</li>
  <li>Orçamento gratuito e sem compromisso</li>
  <li>Garantia formal nos serviços executados</li>
  <li>Suporte técnico pós-entrega</li>
</ul>
<h3>Como funciona o atendimento em {cidade}?</h3>
<p>Ao entrar em contato com a {empresa}, nossa equipe agenda uma visita técnica em {cidade} sem custo. Durante a visita, levantamos todas as informações necessárias para elaborar uma proposta precisa e adequada às suas necessidades. O orçamento é entregue de forma detalhada e transparente.</p>
<h3>Tecnologia e inovação a serviço da indústria</h3>
<p>A {empresa} investe constantemente em atualização técnica e em equipamentos modernos para oferecer o melhor serviço de {kw_lower} em {cidade}. Essa combinação de experiência e tecnologia nos permite entregar projetos com alta precisão e eficiência, reduzindo custos e prazos para nossos clientes.</p>
<p>Solicite agora seu orçamento: <strong>{telefone}</strong> — Atendemos {cidade} e região.</p>
""",
]

# ── Template HTML ──────────────────────────────────────────────────────────────

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{meta_title}</title>
  <meta name="description" content="{meta_desc}">
  <meta name="keywords" content="{meta_keys}">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="{dominio}/{slug}.html">
  <meta property="og:title" content="{meta_title}">
  <meta property="og:description" content="{meta_desc}">
  <meta property="og:type" content="website">
  <meta property="og:url" content="{dominio}/{slug}.html">
  <meta property="og:locale" content="pt_BR">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <header id="site-header">
    <div class="container header-inner">
      <a href="index.html" class="logo">Eco <span>Instalações</span></a>
      <nav id="nav-menu" role="navigation" aria-label="Menu principal">
        <a href="index.html#sobre">Sobre</a>
        <a href="index.html#servicos">Serviços</a>
        <a href="index.html#depoimentos">Depoimentos</a>
        <a href="index.html#localizacao">Localização</a>
        <a href="https://wa.me/{whatsapp}?text=Ol%C3%A1%21+Vim+pelo+site+e+gostaria+de+um+or%C3%A7amento." class="nav-cta" target="_blank" rel="noopener noreferrer">Orçamento Grátis</a>
      </nav>
      <button id="menu-toggle" aria-label="Abrir menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>
  </header>

  <section id="hero">
    <div class="container hero-inner">
      <div class="hero-content">
        <span class="hero-label">{cidade} — {estado}</span>
        <h1 id="hero-title" class="hero-title">{hero_h1}</h1>
        <p id="hero-desc" class="hero-desc">{hero_desc}</p>
        <div class="hero-buttons">
          <a href="https://wa.me/{whatsapp}?text=Ol%C3%A1%21+Vim+pelo+site+e+gostaria+de+um+or%C3%A7amento." class="btn btn-primary" target="_blank" rel="noopener noreferrer">Solicitar Orçamento</a>
          <a href="index.html#servicos" class="btn btn-outline">Ver Serviços</a>
        </div>
      </div>
      <div class="hero-visual" aria-hidden="true">
        <div class="hero-stat"><span class="hero-stat-icon">🏭</span><div><div class="hero-stat-num">+500</div><div class="hero-stat-label">Projetos Executados</div></div></div>
        <div class="hero-stat"><span class="hero-stat-icon">🔩</span><div><div class="hero-stat-num">+10</div><div class="hero-stat-label">Anos de Experiência</div></div></div>
        <div class="hero-stat"><span class="hero-stat-icon">📍</span><div><div class="hero-stat-num">39+</div><div class="hero-stat-label">Cidades Atendidas</div></div></div>
        <div class="hero-stat"><span class="hero-stat-icon">⭐</span><div><div class="hero-stat-num">100%</div><div class="hero-stat-label">Clientes Satisfeitos</div></div></div>
      </div>
    </div>
  </section>

  <section id="sobre">
    <div class="container about-inner">
      <div class="about-visual animate-on-scroll">
        <div class="about-badge"><span>🏆</span><span>Referência em {kw} no PR</span></div>
        <ul class="about-list">
          <li>Equipe técnica certificada e experiente</li>
          <li>Atendimento em {cidade} e região oeste do PR</li>
          <li>Cumprimento rigoroso de prazos e orçamentos</li>
          <li>Normas de segurança NR10, NR12 e NR33</li>
          <li>Suporte pós-serviço e garantia nos trabalhos</li>
          <li>Diagnóstico técnico gratuito em {cidade}</li>
        </ul>
      </div>
      <div class="about-text animate-on-scroll">
        <span class="section-label">Sobre a Empresa</span>
        <h2 id="about-title" class="section-title">{empresa} em {cidade}</h2>
        <div id="about-desc">{about_html}</div>
        <a href="https://wa.me/{whatsapp}?text=Ol%C3%A1%21+Quero+saber+mais+sobre+{kw_enc}+em+{cidade_enc}." class="btn btn-primary" target="_blank" rel="noopener noreferrer" style="margin-top:1.5rem">Fale Conosco</a>
      </div>
    </div>
  </section>

  <section id="servicos">
    <div class="container">
      <div class="features-header animate-on-scroll">
        <span class="section-label">Especialidades</span>
        <h2 id="features-title" class="section-title">Nossos Serviços em {cidade}</h2>
        <p class="section-subtitle">Soluções completas em {kw_lower} para a indústria de {cidade} e região.</p>
      </div>
      <div id="features-list">{features_html}</div>
    </div>
  </section>

  <section id="conteudo-seo">
    <div class="container conteudo-seo">
      <h2>{seo_h2}</h2>
      {seo_body}
    </div>
  </section>

  <!-- Interlinking -->
  <section class="interlinking">
    <div class="container">
      <h2 class="section-title">Veja Também</h2>
      <div class="interlinking-grid">{interlinking_html}</div>
    </div>
  </section>

  <!-- Footer -->
  <footer id="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <a href="index.html" class="logo">Eco <span>Instalações</span></a>
          <p id="footer-desc">{empresa} — soluções completas em montagem, manutenção e estruturas metálicas para a indústria do oeste paranaense.</p>
        </div>
        <div class="footer-col">
          <h4>Serviços</h4>
          <ul>
            <li><a href="index.html#servicos">Montagem Industrial</a></li>
            <li><a href="index.html#servicos">Manutenção Industrial</a></li>
            <li><a href="index.html#servicos">Estruturas Metálicas</a></li>
            <li><a href="index.html#servicos">Caldeiraria e Soldagem</a></li>
            <li><a href="index.html#servicos">Pintura Industrial</a></li>
            <li><a href="index.html#servicos">Hidráulica Industrial</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Contato</h4>
          <ul class="footer-info">
            <li>📞 {telefone}</li>
            <li>📍 {cidade} — {estado}</li>
          </ul>
          <h4 style="margin-top:1.2rem">Horário</h4>
          <ul>
            <li>Segunda a Sábado</li>
            <li>07:00 às 12:00</li>
            <li>14:00 às 20:00</li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2025 {empresa}. Todos os direitos reservados.</p>
      </div>
    </div>
  </footer>

  <a id="whatsapp-float" href="https://wa.me/{whatsapp}?text=Ol%C3%A1%21+Vim+pelo+site+e+gostaria+de+um+or%C3%A7amento." aria-label="WhatsApp" target="_blank" rel="noopener noreferrer">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
  </a>

  <script>window.skipInjection = ['hero', 'about', 'features'];</script>
  <script src="js/colors.js"></script>
  <script src="js/content.js"></script>
  <script src="js/maps.js"></script>
  <script src="js/main.js"></script>

</body>
</html>"""

# ── Gerador principal ──────────────────────────────────────────────────────────

def fmt(template, **kw):
    """Formata string substituindo {placeholders}."""
    try:
        return template.format(**kw)
    except KeyError:
        return template

def build_features_html(kw, cidade, estado, sample_features):
    cards = []
    for title, desc in sample_features:
        title_f = fmt(title, kw=kw, kw_lower=kw.lower(), cidade=cidade, estado=estado,
                      empresa=EMPRESA, telefone=TELEFONE)
        desc_f  = fmt(desc,  kw=kw, kw_lower=kw.lower(), cidade=cidade, estado=estado,
                      empresa=EMPRESA, telefone=TELEFONE)
        cards.append(f'<div class="feature-card"><h3>{title_f}</h3><p>{desc_f}</p></div>')
    return '\n'.join(cards)

def build_about_html(paras, kw, cidade, estado):
    rendered = []
    for p in paras:
        rendered.append('<p>' + fmt(p, kw=kw, kw_lower=kw.lower(), cidade=cidade,
                                    estado=estado, empresa=EMPRESA, telefone=TELEFONE) + '</p>')
    return '\n'.join(rendered)

def build_interlinking(all_pages, current_slug, n=6):
    candidates = [(s, t) for s, t in all_pages if s != current_slug]
    selected   = random.sample(candidates, min(n, len(candidates)))
    items = []
    for slug, title in selected:
        items.append(f'<div class="interlinking-item"><a href="{slug}.html">{title}</a></div>')
    return '\n'.join(items)

def generate_pages():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir    = os.path.dirname(current_dir)
    site_dir    = os.path.join(base_dir, 'site')
    pages_file  = os.path.join(current_dir, '9_paginas.md')

    if not os.path.exists(pages_file):
        print(f"Erro: {pages_file} não encontrado.")
        return

    with open(pages_file, 'r', encoding='utf-8') as f:
        titles = [l.strip() for l in f if l.strip()]

    # Pré-computa slugs para interlinking
    all_pages = [(slugify(t), t) for t in titles]

    total = len(titles)
    print(f"Gerando {total} páginas...")

    # Seed para reprodutibilidade (mas variada por índice)
    for idx, title in enumerate(titles):
        parts  = title.rsplit(' ', 1)
        cidade = parts[-1] if len(parts) == 2 else "Paraná"
        kw     = parts[0]  if len(parts) == 2 else title
        slug   = slugify(title)

        # Deterministic but varied selection based on index
        random.seed(idx * 7 + 13)

        hero_desc_t  = HERO_DESCS[idx % len(HERO_DESCS)]
        about_paras  = ABOUT_PARAS[idx % len(ABOUT_PARAS)]
        seo_h2_t     = SEO_H2_TEMPLATES[idx % len(SEO_H2_TEMPLATES)]
        seo_body_t   = SEO_BODIES[idx % len(SEO_BODIES)]

        # Pick 4 features (varied)
        feat_pool    = FEATURES_POOL[:]
        random.shuffle(feat_pool)
        sample_feats = feat_pool[:4]

        # Interlinking
        interlinking = build_interlinking(all_pages, slug, n=6)

        # Render strings
        kw_lower = kw.lower()
        ctx = dict(kw=kw, kw_lower=kw_lower, cidade=cidade, estado=ESTADO,
                   empresa=EMPRESA, telefone=TELEFONE, horario=HORARIO,
                   dominio=DOMINIO, slug=slug, whatsapp=WHATSAPP,
                   kw_enc=kw_lower.replace(' ', '+'),
                   cidade_enc=cidade.replace(' ', '+'))

        meta_title = f"{kw} em {cidade} | {EMPRESA}"
        meta_desc  = f"Contrate {kw_lower} em {cidade} com a {EMPRESA}. Equipe certificada, orçamento gratuito e garantia nos serviços. Ligue: {TELEFONE}."
        meta_keys  = f"{kw_lower}, {kw_lower} {cidade}, empresa de {kw_lower} {cidade}, {EMPRESA}, manutenção industrial {cidade}, montagem industrial {cidade}"

        hero_h1   = f"{kw} em {cidade}"
        hero_desc = fmt(hero_desc_t, **ctx)
        about_html = build_about_html(about_paras, kw, cidade, ESTADO)
        features_html = build_features_html(kw, cidade, ESTADO, sample_feats)
        seo_h2    = fmt(seo_h2_t, **ctx)
        seo_body  = fmt(seo_body_t, **ctx)

        html = HTML_TEMPLATE.format(
            meta_title=meta_title,
            meta_desc=meta_desc,
            meta_keys=meta_keys,
            dominio=DOMINIO,
            slug=slug,
            cidade=cidade,
            estado=ESTADO,
            empresa=EMPRESA,
            telefone=TELEFONE,
            whatsapp=WHATSAPP,
            kw=kw,
            kw_lower=kw_lower,
            kw_enc=kw_lower.replace(' ', '+'),
            cidade_enc=cidade.replace(' ', '+'),
            hero_h1=hero_h1,
            hero_desc=hero_desc,
            about_html=about_html,
            features_html=features_html,
            seo_h2=seo_h2,
            seo_body=seo_body,
            interlinking_html=interlinking,
            horario=HORARIO,
        )

        out_path = os.path.join(site_dir, f"{slug}.html")
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(html)

        if (idx + 1) % 100 == 0 or (idx + 1) == total:
            print(f"  {idx+1}/{total} páginas geradas...")

    print(f"\nConcluído! {total} páginas criadas em {site_dir}/")

if __name__ == "__main__":
    generate_pages()
