"""
Script para gerar o mapa do site (HTML) e sitemap (XML).
Lê '9_paginas.md', processa os títulos e gera 'mapa-do-site.html' e 'sitemap.xml' na pasta 'site'.
"""
import os
import unicodedata
import re

def slugify(value):
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    value = re.sub(r'[^\w\s-]', '', value).strip().lower()
    return re.sub(r'[-\s]+', '-', value)

def create_sitemap_and_map():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(current_dir)
    site_dir = os.path.join(base_dir, 'site')

    if not os.path.exists(site_dir):
        os.makedirs(site_dir)

    input_path = os.path.join(base_dir, 'markups', '9_paginas.md')
    config_path = os.path.join(base_dir, 'markups', '0_customizacao.md')
    mapa_html_path = os.path.join(site_dir, 'mapa-do-site.html')
    sitemap_xml_path = os.path.join(site_dir, 'sitemap.xml')

    if not os.path.exists(input_path):
        print(f"Erro: Arquivo {input_path} não encontrado.")
        return

    domain = "https://exemplo.com.br"
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            for line in f:
                if 'DOMINIO_DO_SITE' in line:
                    match = re.search(r':\s*(.+)', line)
                    if match:
                        domain = f"https://{match.group(1).strip()}"
                        break

    print(f"Lendo títulos de {input_path}...")
    with open(input_path, 'r', encoding='utf-8') as f:
        pages_titles = [line.strip() for line in f if line.strip()]

    pages_data = []
    for title in pages_titles:
        slug = slugify(title)
        pages_data.append({'title': title, 'url': f"{slug}.html"})

    print("Gerando mapa-do-site.html...")
    html_content = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mapa do Site - Eco Instalações Industriais</title>
    <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; padding: 40px; max-width: 1200px; margin: 0 auto; background-color: #f4f4f9; color: #333; }}
        h1 {{ border-bottom: 3px solid #F97316; padding-bottom: 15px; color: #0F172A; text-align: center; }}
        .links-container {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 15px; margin-top: 30px; }}
        .link-item {{ background: #fff; padding: 10px 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); transition: transform 0.2s; }}
        .link-item:hover {{ transform: translateY(-3px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }}
        a {{ text-decoration: none; color: #F97316; font-size: 14px; font-weight: 500; }}
        a:hover {{ color: #ea6c0a; }}
        .footer-links {{ margin-bottom: 30px; padding: 20px; background: #e9ecef; border-radius: 8px; text-align: center; }}
        .footer-links a {{ margin: 0 15px; font-size: 16px; font-weight: bold; text-transform: uppercase; }}
    </style>
</head>
<body>
    <h1>Mapa do Site</h1>
    <div class="footer-links">
        <a href="index.html">Página Inicial</a>
        <a href="mapa-do-site.html">Mapa do Site</a>
    </div>
    <div class="links-container">
"""
    for page in pages_data:
        html_content += f'        <div class="link-item"><a href="{page["url"]}">{page["title"]}</a></div>\n'

    html_content += """    </div>
</body>
</html>"""

    with open(mapa_html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"Sucesso! {mapa_html_path} gerado com {len(pages_data) + 2} links.")

    print("Gerando sitemap.xml...")
    xml_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>{domain}/index.html</loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>
    <url>
        <loc>{domain}/mapa-do-site.html</loc>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>
"""
    for page in pages_data:
        xml_content += f"""    <url>
        <loc>{domain}/{page['url']}</loc>
        <changefreq>monthly</changefreq>
        <priority>0.6</priority>
    </url>\n"""

    xml_content += "</urlset>"

    with open(sitemap_xml_path, 'w', encoding='utf-8') as f:
        f.write(xml_content)
    print(f"Sucesso! {sitemap_xml_path} gerado com {len(pages_data) + 2} URLs.")

if __name__ == "__main__":
    create_sitemap_and_map()
